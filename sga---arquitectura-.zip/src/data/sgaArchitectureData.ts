export interface UseCase {
  id: string;
  code: string;
  title: string;
  module: 'Autenticación' | 'Gestión académica' | 'Matrícula' | 'Calificaciones' | 'Reportes' | 'Auditoría';
  actor: 'Administrador' | 'Coordinador académico' | 'Docente' | 'Estudiante' | 'Administrador, Coordinador académico, Docente, Estudiante';
  primaryActor: 'Administrador' | 'Coordinador académico' | 'Docente' | 'Estudiante';
  precondition: string;
  mainFlow: string;
  steps: { step: number; actor: string; action: string }[];
  postcondition: string;
  exceptions: string[];
  securityNote: string;
  criticality: 'Crítica' | 'Alta' | 'Media';
}

export const SGA_ACTORS = [
  {
    id: 'Administrador',
    name: 'Administrador',
    roleDescription: 'Gestión global de la plataforma, parametrización del sistema, reportes institucionales y supervisión de auditoría.',
    color: 'indigo',
    badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200 dark:bg-indigo-950/50 dark:text-indigo-300 dark:border-indigo-800',
  },
  {
    id: 'Coordinador académico',
    name: 'Coordinador académico',
    roleDescription: 'Planeación de oferta académica, asignación docente a cursos, gestión de novedades de matrícula y análisis de desempeño.',
    color: 'emerald',
    badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800',
  },
  {
    id: 'Docente',
    name: 'Docente',
    roleDescription: 'Gestión de sus cursos asignados, registro y publicación de evaluaciones y notas por corte.',
    color: 'amber',
    badgeClass: 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800',
  },
  {
    id: 'Estudiante',
    name: 'Estudiante',
    roleDescription: 'Inscripción y selección de asignaturas en matrícula académica y consulta de calificaciones e historial.',
    color: 'sky',
    badgeClass: 'bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-950/50 dark:text-sky-300 dark:border-sky-800',
  },
] as const;

export const SGA_MODULES = [
  {
    id: 'Autenticación',
    name: 'Autenticación',
    description: 'Control de acceso, gestión de sesiones y autorización basada en roles (RBAC).',
    iconName: 'ShieldCheck',
  },
  {
    id: 'Gestión académica',
    name: 'Gestión académica',
    description: 'Configuración de períodos, mallas de asignaturas, grupos de cursos y vinculación docente.',
    iconName: 'GraduationCap',
  },
  {
    id: 'Matrícula',
    name: 'Matrícula',
    description: 'Inscripción de asignaturas por el estudiante y resolución de novedades por coordinación.',
    iconName: 'ClipboardList',
  },
  {
    id: 'Calificaciones',
    name: 'Calificaciones',
    description: 'Asentamiento, cálculo de ponderados, publicación y visualización de notas.',
    iconName: 'Award',
  },
  {
    id: 'Reportes',
    name: 'Reportes',
    description: 'Generación y exportación de métricas analíticas, rendimiento académico y estadísticas del SGA.',
    iconName: 'BarChart3',
  },
  {
    id: 'Auditoría',
    name: 'Auditoría',
    description: 'Trazabilidad inmutable de transacciones críticas, cambios de notas, accesos y operaciones de usuarios.',
    iconName: 'FileSearch',
  },
] as const;

export const SGA_USE_CASES: UseCase[] = [
  {
    id: 'CU01',
    code: 'CU-01',
    title: 'Iniciar Sesión y Control de Acceso',
    module: 'Autenticación',
    actor: 'Administrador, Coordinador académico, Docente, Estudiante',
    primaryActor: 'Administrador',
    criticality: 'Crítica',
    precondition: 'El usuario cuenta con cuenta activa en el sistema y credenciales institucionales vigentes.',
    mainFlow: '1. El usuario ingresa credenciales (identificador y contraseña). 2. El sistema valida identidad y estado activo. 3. El sistema genera token JWT con claims de rol. 4. Redirige al panel correspondiente al perfil verificado.',
    steps: [
      { step: 1, actor: 'Usuario (Cualquier actor)', action: 'Ingresa credenciales de acceso institucional (usuario y contraseña).' },
      { step: 2, actor: 'Sistema (SGA)', action: 'Verifica hash criptográfico de contraseña y valida que la cuenta no esté bloqueada.' },
      { step: 3, actor: 'Sistema (SGA)', action: 'Genera sesión segura con rol asignado y emite evento en el módulo de auditoría.' },
      { step: 4, actor: 'Usuario (Cualquier actor)', action: 'Accede al tablero principal contextualizado a sus permisos autorizados.' },
    ],
    postcondition: 'Sesión activa iniciada; acceso concedido según rol; registro de intento exitoso en el módulo de auditoría.',
    exceptions: [
      'Credenciales inválidas: Sistema incrementa contador de intentos fallidos y notifica al usuario.',
      'Cuenta inactiva o bloqueada: Sistema deniega acceso e instruye contacto con el Administrador.',
    ],
    securityNote: 'Cumple principio de mínimo privilegio. Token de sesión con expiración corta y registro de IP/User-Agent en auditoría.',
  },
  {
    id: 'CU02',
    code: 'CU-02',
    title: 'Configurar Período Académico y Catálogo de Asignaturas',
    module: 'Gestión académica',
    actor: 'Administrador',
    primaryActor: 'Administrador',
    criticality: 'Crítica',
    precondition: 'El Administrador tiene sesión autenticada; se ha definido el calendario académico institucional.',
    mainFlow: '1. El administrador ingresa a gestión académica. 2. Define fechas límite de matrícula, inicio/fin de clases y cortes de evaluación. 3. Configura mallas, códigos y créditos de asignaturas. 4. Confirma y activa el período.',
    steps: [
      { step: 1, actor: 'Administrador', action: 'Accede a la interfaz de parametrización de períodos académicos.' },
      { step: 2, actor: 'Administrador', action: 'Establece vigencia del semestre/ciclo y ventanas temporales de matrícula y notas.' },
      { step: 3, actor: 'Administrador', action: 'Registra o actualiza el catálogo de asignaturas con sus requisitos y créditos.' },
      { step: 4, actor: 'Sistema (SGA)', action: 'Valida coherencia de fechas, persiste el período académico y audita la parametrización.' },
    ],
    postcondition: 'Período académico activo habilitado como contexto operativo para matrículas y planeación docente.',
    exceptions: [
      'Solapamiento de fechas: Sistema alerta inconsistencias entre fechas de inicio, matrícula y cierre.',
      'Código de asignatura duplicado: Rechaza creación y solicita código único.',
    ],
    securityNote: 'Operación restringida exclusivamente al Administrador con registro obligatorio en auditoría.',
  },
  {
    id: 'CU03',
    code: 'CU-03',
    title: 'Programar Oferta Académica y Asignar Docentes a Cursos',
    module: 'Gestión académica',
    actor: 'Coordinador académico',
    primaryActor: 'Coordinador académico',
    criticality: 'Alta',
    precondition: 'El período académico se encuentra creado y activo; docentes registrados y asignaturas configuradas.',
    mainFlow: '1. El coordinador selecciona la asignatura y apertura cursos/grupos con cupos máximos. 2. Asigna horarios y aulas físicas o virtuales. 3. Vincula el docente titular responsable. 4. Publica la oferta para matrícula.',
    steps: [
      { step: 1, actor: 'Coordinador académico', action: 'Selecciona el período académico vigente y consulta asignaturas requeridas.' },
      { step: 2, actor: 'Coordinador académico', action: 'Crea grupos con límite de cupos y franjas horarias.' },
      { step: 3, actor: 'Coordinador académico', action: 'Selecciona y vincula al docente responsable de la cátedra.' },
      { step: 4, actor: 'Sistema (SGA)', action: 'Valida que el docente no presente conflicto horario en otros grupos y publica la oferta.' },
    ],
    postcondition: 'Cursos abiertos con asignación docente confirmada, disponibles para el proceso de matrícula.',
    exceptions: [
      'Cruce horario del docente: El sistema bloquea la asignación y señala la franja horaria en conflicto.',
      'Capacidad de aula excedida: El sistema advierte que el cupo supera la capacidad física registrada.',
    ],
    securityNote: 'Validación de integridad referencial entre Docente, Asignatura y Período.',
  },
  {
    id: 'CU04',
    code: 'CU-04',
    title: 'Realizar Matrícula Académica de Cursos',
    module: 'Matrícula',
    actor: 'Estudiante',
    primaryActor: 'Estudiante',
    criticality: 'Crítica',
    precondition: 'Estudiante autenticado con estado habilitado y dentro de la ventana de fechas de matrícula activa.',
    mainFlow: '1. El estudiante consulta la oferta académica disponible para su plan de estudios. 2. Selecciona grupos verificando disponibilidad de cupo y sin cruce horario. 3. Confirma la inscripción. 4. El sistema consolida la matrícula.',
    steps: [
      { step: 1, actor: 'Estudiante', action: 'Ingresa al módulo de matrícula académica.' },
      { step: 2, actor: 'Estudiante', action: 'Explora cursos ofertados y agrega asignaturas deseadas al horario tentativo.' },
      { step: 3, actor: 'Sistema (SGA)', action: 'Evalúa cumplimiento de prerrequisitos, ausencia de colisión horaria y cupos disponibles en tiempo real.' },
      { step: 4, actor: 'Estudiante', action: 'Confirma la selección definitiva de asignaturas.' },
      { step: 5, actor: 'Sistema (SGA)', action: 'Reserva cupos atómicamente, emite constancia de horario y notifica éxito.' },
    ],
    postcondition: 'Asignaturas formalmente inscritas; cupos descontados en cursos; horario generado para el estudiante.',
    exceptions: [
      'Cupo agotado: El sistema impide la adición e indica lista de espera o grupos alternos.',
      'Cruce de horario: El sistema bloquea la selección e indica las asignaturas en conflicto.',
      'Prerrequisito no aprobado: El sistema bloquea la materia no autorizada por malla curricular.',
    ],
    securityNote: 'Transacción ACID para evitar sobreventa de cupos concurrentes y alteración no autorizada.',
  },
  {
    id: 'CU05',
    code: 'CU-05',
    title: 'Gestionar Novedades y Ajustes Extraordinarios de Matrícula',
    module: 'Matrícula',
    actor: 'Coordinador académico',
    primaryActor: 'Coordinador académico',
    criticality: 'Alta',
    precondition: 'Coordinador académico autenticado; existe solicitud formal de ajuste, cancelación o adición por excepción.',
    mainFlow: '1. El coordinador localiza al estudiante en el sistema. 2. Revisa la carga académica matriculada y el motivo del ajuste. 3. Aplica adición extraordinaria, ampliación de sobrecupo o retiro justificado. 4. Confirma y guarda el cambio.',
    steps: [
      { step: 1, actor: 'Coordinador académico', action: 'Busca el registro del estudiante por número de identificación o código.' },
      { step: 2, actor: 'Coordinador académico', action: 'Evalúa la situación y selecciona la acción (adicionar, cancelar o cambiar de grupo).' },
      { step: 3, actor: 'Coordinador académico', action: 'Ingresa justificativo de la novedad y confirma la modificación.' },
      { step: 4, actor: 'Sistema (SGA)', action: 'Actualiza la matrícula del estudiante, recalcula cupos y registra evento en auditoría.' },
    ],
    postcondition: 'Matrícula del estudiante actualizada fuera de período ordinario; pista de auditoría vinculada al coordinador.',
    exceptions: [
      'Estudiante no registrado: El sistema notifica que el código no corresponde a ningún alumno activo.',
      'Intento de retiro de asignatura ya calificada en corte final: El sistema requiere autorización especial.',
    ],
    securityNote: 'Obliga a justificar el motivo del cambio con trazabilidad estricta en el módulo de auditoría.',
  },
  {
    id: 'CU06',
    code: 'CU-06',
    title: 'Registrar y Publicar Calificaciones Parciales y Finales',
    module: 'Calificaciones',
    actor: 'Docente',
    primaryActor: 'Docente',
    criticality: 'Crítica',
    precondition: 'Docente autenticado con asignación vigente al curso; período o corte de evaluación activo para digitación.',
    mainFlow: '1. El docente selecciona el curso asignado y el corte de evaluación. 2. Visualiza la lista de estudiantes inscritos. 3. Digita las calificaciones numéricas y observaciones. 4. Valida ponderaciones y publica las notas.',
    steps: [
      { step: 1, actor: 'Docente', action: 'Accede a la lista de sus cursos asignados en el período actual.' },
      { step: 2, actor: 'Docente', action: 'Elige el corte de evaluación (parcial 1, parcial 2, examen final, etc.).' },
      { step: 3, actor: 'Docente', action: 'Ingresa o importa las notas numéricas dentro de la escala oficial (ej. 0.0 a 5.0).' },
      { step: 4, actor: 'Sistema (SGA)', action: 'Verifica rangos válidos, calcula promedios ponderados y solicita confirmación de publicación.' },
      { step: 5, actor: 'Docente', action: 'Confirma publicación definitiva de calificaciones.' },
    ],
    postcondition: 'Calificaciones asentadas en base de datos; promedios calculados y visibles para estudiantes y coordinadores.',
    exceptions: [
      'Nota fuera de escala permitida: Sistema bloquea guardado e indica rango admisible.',
      'Fecha límite de corte vencida: Sistema deshabilita edición y orienta solicitar apertura a Coordinador.',
    ],
    securityNote: 'Solo el docente titular puede asentar notas en su curso. Modificaciones posteriores generan log de auditoría.',
  },
  {
    id: 'CU07',
    code: 'CU-07',
    title: 'Consultar Historial Académico y Calificaciones',
    module: 'Calificaciones',
    actor: 'Estudiante',
    primaryActor: 'Estudiante',
    criticality: 'Alta',
    precondition: 'Estudiante autenticado con asignaturas matriculadas en el período actual o con histórico cursado.',
    mainFlow: '1. El estudiante accede a la sección de calificaciones. 2. Selecciona el período a consultar (actual o histórico). 3. El sistema muestra desglose de notas por corte, ponderados, nota final y estado de aprobación.',
    steps: [
      { step: 1, actor: 'Estudiante', action: 'Ingresa al módulo de calificaciones desde su portal.' },
      { step: 2, actor: 'Estudiante', action: 'Selecciona el período académico de interés o vista de sábana general.' },
      { step: 3, actor: 'Sistema (SGA)', action: 'Recupera notas publicadas por los docentes, créditos aprobados y promedio semestral/acumulado.' },
      { step: 4, actor: 'Estudiante', action: 'Visualiza el reporte detallado e interactúa con el desglose de cada corte evaluado.' },
    ],
    postcondition: 'Estado académico y notas visualizadas de manera transparente por el estudiante sin permisos de edición.',
    exceptions: [
      'Notas aún en borrador no publicadas por el docente: El sistema muestra el estado "Pendiente de publicación".',
    ],
    securityNote: 'Aislamiento estricto de datos: un estudiante solo puede consultar su propio récord académico.',
  },
  {
    id: 'CU08',
    code: 'CU-08',
    title: 'Generar Reportes de Desempeño Académico y Aprobación',
    module: 'Reportes',
    actor: 'Coordinador académico',
    primaryActor: 'Coordinador académico',
    criticality: 'Alta',
    precondition: 'Coordinador académico autenticado con cursos y calificaciones registradas en el período evaluado.',
    mainFlow: '1. El coordinador define parámetros del reporte (programa, período, asignatura, docente o tasa de riesgo). 2. Solicita el consolidado. 3. El sistema calcula indicadores académicos (tasas de aprobación, deserción y promedios). 4. Exporta el reporte.',
    steps: [
      { step: 1, actor: 'Coordinador académico', action: 'Accede al módulo de reportes académicos.' },
      { step: 2, actor: 'Coordinador académico', action: 'Aplica filtros analíticos: por curso, por docente o alertas de bajo rendimiento.' },
      { step: 3, actor: 'Sistema (SGA)', action: 'Ejecuta agregaciones analíticas y proyecta métricas comparativas en gráficos y tablas.' },
      { step: 4, actor: 'Coordinador académico', action: 'Descarga el informe en formato estándar (PDF o Excel) para comités curriculares.' },
    ],
    postcondition: 'Informe analítico generado para toma de decisiones pedagógicas y seguimiento a planes de mejoramiento.',
    exceptions: [
      'Sin datos suficientes: El sistema advierte que el período seleccionado aún no cuenta con notas publicadas.',
    ],
    securityNote: 'Acceso a nivel de facultad o programa coordinado, con trazabilidad de consulta en auditoría.',
  },
  {
    id: 'CU09',
    code: 'CU-09',
    title: 'Generar Reportes Estadísticos e Institucionales del Sistema',
    module: 'Reportes',
    actor: 'Administrador',
    primaryActor: 'Administrador',
    criticality: 'Media',
    precondition: 'Administrador autenticado con permisos globales sobre la plataforma.',
    mainFlow: '1. El administrador elige tipo de informe institucional (total de matrículas, ocupación de cupos o usuarios activos). 2. Configura rango temporal. 3. El sistema procesa los volúmenes de datos. 4. Genera y emite el reporte consolidado.',
    steps: [
      { step: 1, actor: 'Administrador', action: 'Ingresa al generador de reportes institucionales.' },
      { step: 2, actor: 'Administrador', action: 'Selecciona dimensiones: volumen de matrículas globales, ocupación por facultad o carga horaria docente.' },
      { step: 3, actor: 'Sistema (SGA)', action: 'Procesa las métricas a nivel base de datos y genera visualizaciones ejecutivas.' },
      { step: 4, actor: 'Administrador', action: 'Exporta el consolidado institucional para rectoría o entes reguladores.' },
    ],
    postcondition: 'Reporte macro institucional exportado para planeación de recursos y cumplimiento normativo.',
    exceptions: [
      'Rango de fechas inválido: Sistema solicita corrección del intervalo temporal seleccionado.',
    ],
    securityNote: 'Permisos de lectura global asegurados mediante rol administrador.',
  },
  {
    id: 'CU10',
    code: 'CU-10',
    title: 'Consultar y Exportar Pistas de Auditoría y Logs de Seguridad',
    module: 'Auditoría',
    actor: 'Administrador',
    primaryActor: 'Administrador',
    criticality: 'Crítica',
    precondition: 'Administrador autenticado; eventos de sistema registrados previamente en el log inmutable.',
    mainFlow: '1. El administrador ingresa a auditoría. 2. Filtra eventos por actor, módulo, rango de fechas o tipo de transacción (ej. cambio de nota, matrícula forzada). 3. Inspecciona la traza con datos anteriores y nuevos. 4. Exporta el expediente probatorio.',
    steps: [
      { step: 1, actor: 'Administrador', action: 'Accede a la consola de auditoría del SGA.' },
      { step: 2, actor: 'Administrador', action: 'Define criterios de búsqueda: usuario, módulo afectado, rango temporal o nivel de criticidad.' },
      { step: 3, actor: 'Sistema (SGA)', action: 'Consulta el registro inmutable de auditoría mostrando timestamp, IP, actor, acción y diff de datos.' },
      { step: 4, actor: 'Administrador', action: 'Inspecciona el detalle forense y descarga el log criptográficamente firmado si es requerido.' },
    ],
    postcondition: 'Trazabilidad de operaciones verificada; informe forense de auditoría generado sin posibilidad de alteración del registro.',
    exceptions: [
      'Sin coincidencias: El sistema indica que no existen eventos para los filtros seleccionados.',
    ],
    securityNote: 'Almacenamiento WORM (Write Once, Read Many). Los logs son de solo lectura y nunca pueden ser borrados ni modificados.',
  },
];
