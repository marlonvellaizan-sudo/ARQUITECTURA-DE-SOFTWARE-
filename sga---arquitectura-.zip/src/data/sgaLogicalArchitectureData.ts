export interface LogicalComponent {
  id: string;
  name: string;
  packageKey: string;
  category: 'Seguridad' | 'Dominio Académico' | 'Analítica' | 'Transversal / Soporte' | 'Persistencia';
  responsibility: string;
  restEndpoints: {
    method: 'GET' | 'POST' | 'PUT' | 'DELETE';
    path: string;
    description: string;
    rolesAllowed: string[];
  }[];
  internalInterfaces?: string[];
  allowedDependencies: {
    target: string;
    reason: string;
    couplingType: 'Llamada directa sincrónica' | 'Eventos asíncronos / Interfaz desacoplada' | 'Driver / Contrato';
  }[];
  prohibitedDependencies: {
    target: string;
    reasonToPreventCycle: string;
  }[];
  nonFunctionalRequirements: {
    category: 'Seguridad' | 'Rendimiento' | 'Consistencia ACID' | 'Auditabilidad / No repudio' | 'Disponibilidad' | 'Mantenibilidad';
    description: string;
    metricTarget: string;
  }[];
}

export const MODULAR_MONOLITH_COMPONENTS: LogicalComponent[] = [
  {
    id: 'auth-module',
    name: 'Autenticación / Autorización',
    packageKey: 'com.sga.modules.auth',
    category: 'Seguridad',
    responsibility:
      'Gestión de credenciales institucionales, generación y validación de tokens JWT sin estado, control de sesiones, aplicación de políticas de autorización basadas en roles (RBAC) y filtrado de solicitudes para todos los actores.',
    restEndpoints: [
      {
        method: 'POST',
        path: '/api/v1/auth/login',
        description: 'Autenticación de credenciales (identificador y contraseña) y emisión de JWT con claims de rol.',
        rolesAllowed: ['Público'],
      },
      {
        method: 'POST',
        path: '/api/v1/auth/refresh',
        description: 'Renovación de token de sesión con rotación de Refresh Token.',
        rolesAllowed: ['Todos los actores'],
      },
      {
        method: 'POST',
        path: '/api/v1/auth/logout',
        description: 'Revocación e invalidación de token activo.',
        rolesAllowed: ['Todos los actores'],
      },
      {
        method: 'GET',
        path: '/api/v1/auth/me',
        description: 'Consulta del perfil activo, roles y permisos asignados.',
        rolesAllowed: ['Todos los actores'],
      },
    ],
    internalInterfaces: [
      'AuthGuard / RBACInterceptor (Middleware en memoria que valida tokens y permisos de cada endpoint)',
      'SecurityContextHolder (Contexto del hilo con identidad del usuario en sesión)',
    ],
    allowedDependencies: [
      {
        target: 'Capa de Acceso a Datos (DAL)',
        reason: 'Consulta de usuarios, validación de hash bcrypt/argon2 y estado de cuenta.',
        couplingType: 'Llamada directa sincrónica',
      },
      {
        target: 'Auditoría',
        reason: 'Emisión de eventos de seguridad (logins exitosos, intentos fallidos, bloqueos de cuenta).',
        couplingType: 'Eventos asíncronos / Interfaz desacoplada',
      },
    ],
    prohibitedDependencies: [
      {
        target: 'Gestión Académica',
        reasonToPreventCycle: 'El subsistema de identidad debe ser agnóstico del catálogo de materias y períodos para evitar acoplamiento circular con el dominio.',
      },
      {
        target: 'Matrícula',
        reasonToPreventCycle: 'Autenticación no debe conocer inscripciones ni cupos; crearía un ciclo directo si Matrícula consulta Auth para validar identidad.',
      },
      {
        target: 'Calificaciones',
        reasonToPreventCycle: 'Seguridad base es un componente fundacional; no debe tener dependencia de evaluación ni notas.',
      },
      {
        target: 'Reportes',
        reasonToPreventCycle: 'Reportes es un módulo consumidor superior; Auth nunca debe consultar reportes.',
      },
    ],
    nonFunctionalRequirements: [
      {
        category: 'Seguridad',
        description: 'Contraseñas almacenadas con Argon2id/Bcrypt; tokens JWT firmados con RS256 de corta vigencia (15 min).',
        metricTarget: 'Protección contra fugas de credenciales y replay attacks.',
      },
      {
        category: 'Rendimiento',
        description: 'Validación en memoria de firmas criptográficas JWT sin consultar la BD en cada request.',
        metricTarget: 'Latencia de validación de autenticación < 5ms.',
      },
    ],
  },
  {
    id: 'academic-module',
    name: 'Gestión Académica',
    packageKey: 'com.sga.modules.academic',
    category: 'Dominio Académico',
    responsibility:
      'Parametrización del calendario institucional, períodos académicos vigentes, catálogo de asignaturas con sus créditos y prerrequisitos, programación de la oferta académica (grupos, aulas, horarios) y asignación docente.',
    restEndpoints: [
      {
        method: 'GET',
        path: '/api/v1/academic/periods',
        description: 'Listado de períodos académicos y calendarios de matrícula/notas.',
        rolesAllowed: ['Administrador', 'Coordinador académico', 'Docente', 'Estudiante'],
      },
      {
        method: 'POST',
        path: '/api/v1/academic/periods',
        description: 'Apertura y parametrización de un nuevo período académico institucional.',
        rolesAllowed: ['Administrador'],
      },
      {
        method: 'GET',
        path: '/api/v1/academic/courses',
        description: 'Catálogo de asignaturas con créditos y mallas curriculares.',
        rolesAllowed: ['Administrador', 'Coordinador académico', 'Docente', 'Estudiante'],
      },
      {
        method: 'POST',
        path: '/api/v1/academic/courses',
        description: 'Creación o actualización de asignaturas y prerrequisitos.',
        rolesAllowed: ['Administrador'],
      },
      {
        method: 'GET',
        path: '/api/v1/academic/offerings',
        description: 'Consulta de la oferta académica programada para el período.',
        rolesAllowed: ['Administrador', 'Coordinador académico', 'Docente', 'Estudiante'],
      },
      {
        method: 'POST',
        path: '/api/v1/academic/offerings',
        description: 'Apertura de cursos/grupos con cupos y horarios.',
        rolesAllowed: ['Coordinador académico'],
      },
      {
        method: 'PUT',
        path: '/api/v1/academic/offerings/{offeringId}/teacher',
        description: 'Asignación de docente titular a un curso específico.',
        rolesAllowed: ['Coordinador académico'],
      },
    ],
    internalInterfaces: [
      'AcademicCatalogService (API Java/TypeScript en memoria para que Matrícula consulte mallas y prerrequisitos)',
      'CourseOfferingQueryService (Consulta de grupos abiertos, docentes y horarios)',
    ],
    allowedDependencies: [
      {
        target: 'Capa de Acceso a Datos (DAL)',
        reason: 'Persistencia de períodos, asignaturas, planes de estudio y oferta de grupos.',
        couplingType: 'Llamada directa sincrónica',
      },
      {
        target: 'Auditoría',
        reason: 'Trazabilidad de cambios en mallas, apertura de períodos y asignación de profesores.',
        couplingType: 'Eventos asíncronos / Interfaz desacoplada',
      },
    ],
    prohibitedDependencies: [
      {
        target: 'Matrícula',
        reasonToPreventCycle: 'El catálogo y la oferta existen de forma independiente de si hay estudiantes inscritos. Si Gestión Académica dependiera de Matrícula se generaría un ciclo fatal: Matrícula -> Académica -> Matrícula.',
      },
      {
        target: 'Calificaciones',
        reasonToPreventCycle: 'La estructura de asignaturas no depende de las notas emitidas.',
      },
      {
        target: 'Reportes',
        reasonToPreventCycle: 'Los módulos de dominio nunca deben consultar al módulo de reportería.',
      },
    ],
    nonFunctionalRequirements: [
      {
        category: 'Consistencia ACID',
        description: 'Integridad referencial estricta entre programas, asignaturas y prerrequisitos en base de datos.',
        metricTarget: 'Cero referencias huérfanas en mallas curriculares.',
      },
      {
        category: 'Disponibilidad',
        description: 'Caché en memoria (Read-Through) de catálogo de materias y oferta durante semanas de matrícula.',
        metricTarget: '99.95% de disponibilidad en consulta de oferta.',
      },
    ],
  },
  {
    id: 'enrollment-module',
    name: 'Matrícula',
    packageKey: 'com.sga.modules.enrollment',
    category: 'Dominio Académico',
    responsibility:
      'Control de inscripciones de asignaturas por el estudiante, verificación concurrente de cupos en tiempo real, validación de prerrequisitos aprobados, detección de cruces de horario y procesamiento de ajustes/novedades por coordinación.',
    restEndpoints: [
      {
        method: 'GET',
        path: '/api/v1/enrollment/student/{studentId}/eligible-courses',
        description: 'Asignaturas habilitadas para matrícula según la malla curricular del estudiante.',
        rolesAllowed: ['Estudiante', 'Coordinador académico'],
      },
      {
        method: 'POST',
        path: '/api/v1/enrollment/register',
        description: 'Inscripción de asignaturas con reserva atómica de cupos y consolidación de horario.',
        rolesAllowed: ['Estudiante'],
      },
      {
        method: 'GET',
        path: '/api/v1/enrollment/student/{studentId}/schedule',
        description: 'Consulta del horario consolidado de clases del estudiante.',
        rolesAllowed: ['Estudiante', 'Coordinador académico', 'Administrador'],
      },
      {
        method: 'POST',
        path: '/api/v1/enrollment/adjustments',
        description: 'Adición, cancelación justificada o sobrecupo extraordinario por coordinación.',
        rolesAllowed: ['Coordinador académico'],
      },
      {
        method: 'DELETE',
        path: '/api/v1/enrollment/{enrollmentId}',
        description: 'Retiro o cancelación de una materia matriculada dentro de los plazos reglamentarios.',
        rolesAllowed: ['Estudiante', 'Coordinador académico'],
      },
    ],
    internalInterfaces: [
      'EnrollmentQueryService (Interfaz en memoria para que Calificaciones consulte qué estudiantes están legalmente inscritos en un curso)',
      'EnrollmentEventPublisher (Emite evento EstudianteMatriculado para inicializar listas)',
    ],
    allowedDependencies: [
      {
        target: 'Gestión Académica',
        reason: 'Consumo de AcademicCatalogService para verificar horarios, asignaturas habilitadas y cupo máximo de grupos.',
        couplingType: 'Llamada directa sincrónica',
      },
      {
        target: 'Capa de Acceso a Datos (DAL)',
        reason: 'Transacciones ACID con bloqueo pesimista o select-for-update para decremento atómico de cupos.',
        couplingType: 'Llamada directa sincrónica',
      },
      {
        target: 'Auditoría',
        reason: 'Registro inmutable de cada inscripción, cancelación y novedad extraordinaria autorizada.',
        couplingType: 'Eventos asíncronos / Interfaz desacoplada',
      },
    ],
    prohibitedDependencies: [
      {
        target: 'Calificaciones',
        reasonToPreventCycle: 'Matrícula no debe invocar al módulo de Calificaciones. La verificación de prerrequisitos debe realizarse mediante un historial consolidado en DAL o evento histórico, no acoplándose a la lógica de calificaciones.',
      },
      {
        target: 'Reportes',
        reasonToPreventCycle: 'La lógica transaccional de matrícula no debe llamar a reportes.',
      },
      {
        target: 'Autenticación (lógica de negocio)',
        reasonToPreventCycle: 'No debe llamar servicios internos de Auth más allá del SecurityContext inyectado por middleware.',
      },
    ],
    nonFunctionalRequirements: [
      {
        category: 'Consistencia ACID',
        description: 'Aislamiento transaccional SERIALIZABLE o SELECT FOR UPDATE en la reserva de cupos concurrentes.',
        metricTarget: '0 sobreventas de cupos bajo 5,000 solicitudes concurrentes.',
      },
      {
        category: 'Rendimiento',
        description: 'Tiempo de respuesta en la confirmación de matrícula bajo carga masiva pico.',
        metricTarget: 'Latencia p95 < 250ms.',
      },
    ],
  },
  {
    id: 'grading-module',
    name: 'Calificaciones',
    packageKey: 'com.sga.modules.grading',
    category: 'Dominio Académico',
    responsibility:
      'Configuración de cortes evaluativos, registro y publicación de notas parciales y finales por parte de los docentes, cálculo automatizado de promedios ponderados y consulta del historial académico/sábana de notas por estudiantes.',
    restEndpoints: [
      {
        method: 'GET',
        path: '/api/v1/grading/course/{courseId}/roster',
        description: 'Lista de estudiantes matriculados en el curso para asentamiento de calificaciones.',
        rolesAllowed: ['Docente', 'Coordinador académico'],
      },
      {
        method: 'POST',
        path: '/api/v1/grading/grades',
        description: 'Registro de calificaciones parciales dentro de la escala oficial (ej. 0.0 a 5.0).',
        rolesAllowed: ['Docente'],
      },
      {
        method: 'PUT',
        path: '/api/v1/grading/publish/{courseId}/{termId}',
        description: 'Publicación oficial y cierre de edición del corte de notas del curso.',
        rolesAllowed: ['Docente'],
      },
      {
        method: 'GET',
        path: '/api/v1/grading/student/{studentId}/grades',
        description: 'Consulta del récord de notas del período actual y estado de aprobación.',
        rolesAllowed: ['Estudiante', 'Coordinador académico'],
      },
      {
        method: 'GET',
        path: '/api/v1/grading/student/{studentId}/transcript',
        description: 'Historial académico consolidado y cálculo de promedio acumulado general.',
        rolesAllowed: ['Estudiante', 'Coordinador académico', 'Administrador'],
      },
      {
        method: 'PUT',
        path: '/api/v1/grading/adjustments/{gradeId}',
        description: 'Modificación excepcional de nota posterior al cierre de corte con justificación.',
        rolesAllowed: ['Coordinador académico'],
      },
    ],
    internalInterfaces: [
      'GradingQueryService (Interfaz en memoria para consultar si un estudiante aprobó una asignatura previa)',
    ],
    allowedDependencies: [
      {
        target: 'Gestión Académica',
        reason: 'Verificación de escalas evaluativas, cortes del período y asignaturas cursadas.',
        couplingType: 'Llamada directa sincrónica',
      },
      {
        target: 'Matrícula',
        reason: 'Consumo de EnrollmentQueryService para obtener la lista oficial de estudiantes válidamente inscritos en el curso.',
        couplingType: 'Llamada directa sincrónica',
      },
      {
        target: 'Capa de Acceso a Datos (DAL)',
        reason: 'Persistencia de notas, historial y cálculos de promedios.',
        couplingType: 'Llamada directa sincrónica',
      },
      {
        target: 'Auditoría',
        reason: 'Registro obligatorio de toda inserción, modificación de notas y justificaciones de cambio.',
        couplingType: 'Eventos asíncronos / Interfaz desacoplada',
      },
    ],
    prohibitedDependencies: [
      {
        target: 'Matrícula (llamada inversa de escritura)',
        reasonToPreventCycle: 'Matrícula NO debe depender de Calificaciones. Calificaciones puede leer matrículas mediante interfaz limpia, pero Matrícula jamás debe llamar a Calificaciones en cascada.',
      },
      {
        target: 'Reportes',
        reasonToPreventCycle: 'Calificaciones genera los datos primarios; jamás debe depender del motor de reportes.',
      },
      {
        target: 'Gestión Académica (modificación)',
        reasonToPreventCycle: 'Calificaciones nunca debe modificar cursos ni docentes en el módulo académico.',
      },
    ],
    nonFunctionalRequirements: [
      {
        category: 'Auditabilidad / No repudio',
        description: 'Versionamiento estricto de notas con registro del autor docente, IP, marca temporal y nota previa.',
        metricTarget: '100% de modificaciones de notas auditadas.',
      },
      {
        category: 'Consistencia ACID',
        description: 'Cálculo de ponderados transaccional que asegura que la nota final refleje la suma exacta de los porcentajes de corte.',
        metricTarget: 'Precisión matemática de 2 decimales sin desincronización.',
      },
    ],
  },
  {
    id: 'reports-module',
    name: 'Reportes',
    packageKey: 'com.sga.modules.reports',
    category: 'Analítica',
    responsibility:
      'Compilación, agregación analítica y generación de informes institucionales y de gestión académica: tasas de aprobación y reprobación, ocupación de cupos, volumen de matrículas, estudiantes en riesgo y reportes estadísticos globales.',
    restEndpoints: [
      {
        method: 'POST',
        path: '/api/v1/reports/academic-performance',
        description: 'Generación de informe de desempeño por programa, asignatura, curso o docente.',
        rolesAllowed: ['Coordinador académico', 'Administrador'],
      },
      {
        method: 'POST',
        path: '/api/v1/reports/enrollment-stats',
        description: 'Estadísticas de matrículas globales, ocupación de aulas y retención estudiantil.',
        rolesAllowed: ['Administrador', 'Coordinador académico'],
      },
      {
        method: 'POST',
        path: '/api/v1/reports/at-risk-students',
        description: 'Detección temprana de estudiantes con promedios en riesgo de pérdida académica.',
        rolesAllowed: ['Coordinador académico'],
      },
      {
        method: 'GET',
        path: '/api/v1/reports/export/{jobId}/download',
        description: 'Descarga del informe procesado en formato estándar PDF o XLSX.',
        rolesAllowed: ['Administrador', 'Coordinador académico'],
      },
    ],
    internalInterfaces: [
      'ReportGeneratorJob (Procesador asíncrono para reportes pesados sin bloquear hilos HTTP)',
    ],
    allowedDependencies: [
      {
        target: 'Capa de Acceso a Datos (DAL)',
        reason: 'Consultas analíticas optimizadas de solo lectura (Read Models / Vistas SQL de solo lectura).',
        couplingType: 'Llamada directa sincrónica',
      },
      {
        target: 'Auditoría',
        reason: 'Registro de solicitudes de generación y descarga de información analítica sensible.',
        couplingType: 'Eventos asíncronos / Interfaz desacoplada',
      },
    ],
    prohibitedDependencies: [
      {
        target: 'Cualquier módulo de negocio como dependiente de Reportes',
        reasonToPreventCycle: 'NINGÚN módulo del sistema (Auth, Académica, Matrícula, Calificaciones) debe depender de Reportes. Reportes es un nodo hoja (Leaf Node) en el grafo de dependencias.',
      },
      {
        target: 'Escritura en módulos de negocio',
        reasonToPreventCycle: 'Reportes nunca debe ejecutar operaciones de mutación (INSERT/UPDATE/DELETE) en las tablas operativas de negocio.',
      },
    ],
    nonFunctionalRequirements: [
      {
        category: 'Rendimiento',
        description: 'Aislamiento de la carga analítica; las consultas pesadas se ejecutan con réplicas de lectura o transacciones READ UNCOMMITTED/READ COMMITTED snapshot.',
        metricTarget: 'Cero degradación de los tiempos de respuesta de matrícula o calificaciones durante la generación de reportes.',
      },
      {
        category: 'Mantenibilidad',
        description: 'Generación asíncrona mediante colas de trabajo en memoria para reportes institucionales grandes.',
        metricTarget: 'Generación de documentos PDF/Excel en < 5s.',
      },
    ],
  },
  {
    id: 'audit-module',
    name: 'Auditoría',
    packageKey: 'com.sga.modules.audit',
    category: 'Transversal / Soporte',
    responsibility:
      'Recepción, persistencia inmutable y consulta centralizada de pistas de auditoría (logs de seguridad, transacciones críticas, cambios de notas, cancelaciones de matrícula y parametrizaciones del sistema) con diff de datos antes y después.',
    restEndpoints: [
      {
        method: 'POST',
        path: '/api/v1/audit/events',
        description: 'Endpoint interno/interfaz para registrar eventos de auditoría desde otros módulos.',
        rolesAllowed: ['Servicios internos'],
      },
      {
        method: 'GET',
        path: '/api/v1/audit/logs',
        description: 'Consulta y filtrado de pistas de auditoría por actor, módulo, IP y rango temporal.',
        rolesAllowed: ['Administrador'],
      },
      {
        method: 'GET',
        path: '/api/v1/audit/logs/export',
        description: 'Exportación de expediente probatorio forense sellado criptográficamente.',
        rolesAllowed: ['Administrador'],
      },
    ],
    internalInterfaces: [
      'AuditLogService (Servicio interno inyectable en el monolito modular: auditLogService.recordEvent(...))',
      'AuditEventListener (Consumidor de eventos desacoplados publicados mediante Spring ApplicationEvent / Node EventBus)',
    ],
    allowedDependencies: [
      {
        target: 'Capa de Acceso a Datos (DAL)',
        reason: 'Persistencia en almacenamiento de sólo adición (Append-Only / WORM) sin operaciones de borrado.',
        couplingType: 'Llamada directa sincrónica',
      },
    ],
    prohibitedDependencies: [
      {
        target: 'Módulos de negocio (Académica, Matrícula, Calificaciones, Reportes)',
        reasonToPreventCycle: 'Auditoría es un servicio transversal puramente pasivo receptor. Si Auditoría llamara a un módulo de negocio para enriquecer datos sincrónicamente, crearía ciclos destructivos.',
      },
    ],
    nonFunctionalRequirements: [
      {
        category: 'Auditabilidad / No repudio',
        description: 'Almacenamiento Append-Only inmutable (WORM). Las tablas de auditoría deniegan privilegios SQL de UPDATE y DELETE.',
        metricTarget: '100% de registros inmutables con sello de tiempo UTC y firma hash SHA-256.',
      },
      {
        category: 'Disponibilidad',
        description: 'Desacoplamiento asíncrono para que un fallo eventual en la persistencia del log no interrumpa la transacción del usuario si no es crítica.',
        metricTarget: 'Tiempo de despacho de evento en memoria < 1ms.',
      },
    ],
  },
  {
    id: 'dal-module',
    name: 'Capa de Acceso a Datos (DAL)',
    packageKey: 'com.sga.persistence.dal',
    category: 'Persistencia',
    responsibility:
      'Gestión del pool de conexiones a la base de datos relacional, abstracción ORM/Query Builder, transacciones atómicas ACID, gestión de migraciones de esquemas (flyway/liquibase) y provisión de contratos de repositorio tipados para cada módulo.',
    restEndpoints: [], // DAL is purely internal, no public HTTP REST interfaces
    internalInterfaces: [
      'ITransactionManager (Gestor de transacciones atómicas de base de datos)',
      'IUserRepository (Contrato de acceso a usuarios y credenciales)',
      'IAcademicRepository (Contrato de acceso a períodos, asignaturas y grupos)',
      'IEnrollmentRepository (Contrato con soporte para bloqueos SELECT FOR UPDATE en cupos)',
      'IGradeRepository (Contrato de persistencia de calificaciones y ponderados)',
      'IAuditRepository (Contrato Append-Only para inserción de logs)',
    ],
    allowedDependencies: [
      {
        target: 'Driver RDBMS / Motor de Base de Datos Relacional',
        reason: 'Conexión JDBC/TCP nativa al motor de base de datos (PostgreSQL/MySQL/MariaDB).',
        couplingType: 'Driver / Contrato',
      },
    ],
    prohibitedDependencies: [
      {
        target: 'TODOS los módulos de capa superior (Auth, Académica, Matrícula, Calificaciones, Reportes, Auditoría)',
        reasonToPreventCycle: 'Regla inviolable de Arquitectura Limpia: la capa de persistencia jamás debe importar ni depender de controladores, servicios de aplicación o lógica de negocio. La DAL solo implementa interfaces.',
      },
    ],
    nonFunctionalRequirements: [
      {
        category: 'Consistencia ACID',
        description: 'Soporte de niveles de aislamiento transaccional (Read Committed para operaciones estándar, Serializable/Pessimistic Lock para matrícula).',
        metricTarget: 'Cero transacciones incompletas o datos corruptos.',
      },
      {
        category: 'Rendimiento',
        description: 'Pool de conexiones optimizado (ej. HikariCP), índices B-Tree en llaves foráneas y consultas optimizadas.',
        metricTarget: 'Tiempo de checkout de conexión del pool < 10ms.',
      },
    ],
  },
];

export const ANTI_CYCLE_RULES = [
  {
    code: 'ACR-01',
    rule: 'Direccionalidad Estricta en Cascada (DAG)',
    prohibition: 'Matrícula → Gestión Académica es permitido, pero Gestión Académica NUNCA debe importar ni llamar a Matrícula.',
    consequenceIfBroken: 'Generaría un ciclo mortal de compilación e inicialización de beans (Circular Dependency Exception).',
  },
  {
    code: 'ACR-02',
    rule: 'Desacoplamiento entre Matrícula y Calificaciones',
    prohibition: 'Calificaciones consume lista de inscritos de Matrícula (Lectura), pero Matrícula NUNCA debe invocar a Calificaciones.',
    consequenceIfBroken: 'La matrícula de un curso quedaría bloqueada por la lógica o errores del motor de notas.',
  },
  {
    code: 'ACR-03',
    rule: 'Aislamiento de Reportes como Nodo Hoja',
    prohibition: 'NINGÚN componente de negocio puede importar el módulo de Reportes. Reportes es puramente de salida.',
    consequenceIfBroken: 'Contaminación de la lógica transaccional de alta frecuencia con consultas analíticas pesadas.',
  },
  {
    code: 'ACR-04',
    rule: 'Independencia de Autenticación',
    prohibition: 'Autenticación no conoce entidades académicas (Cursos, Matrículas, Notas).',
    consequenceIfBroken: 'Imposibilidad de reutilizar el módulo de seguridad y violación del principio de responsabilidad única (SRP).',
  },
  {
    code: 'ACR-05',
    rule: 'Inversión de Dependencias en la DAL',
    prohibition: 'La Capa de Acceso a Datos (DAL) tiene cero dependencias hacia arriba. Solo es llamada hacia abajo.',
    consequenceIfBroken: 'Destrucción de la arquitectura en capas y acoplamiento severo entre almacenamiento y casos de uso.',
  },
  {
    code: 'ACR-06',
    rule: 'Auditoría mediante Inversión / Eventos',
    prohibition: 'Auditoría nunca debe llamar sincrónicamente a los módulos emisores para pedir datos adicionales.',
    consequenceIfBroken: 'Ciclos de retroalimentación donde un log de auditoría detona otra acción que detona otro log infinitamente.',
  },
];
