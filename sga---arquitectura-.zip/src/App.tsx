import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  GraduationCap,
  ClipboardList,
  Award,
  BarChart3,
  FileSearch,
  CheckCircle2,
  Users,
  Copy,
  Check,
  Download,
  Filter,
  Search,
  Eye,
  Layers,
  ArrowRight,
  Shield,
  FileText,
  Clock,
  Sparkles,
  Database,
  Lock,
  Network,
  AlertOctagon,
  Cpu,
  Server,
  Zap,
  CheckSquare,
  XCircle,
  HelpCircle
} from 'lucide-react';
import { SGA_ACTORS, SGA_MODULES, SGA_USE_CASES, UseCase } from './data/sgaArchitectureData';
import {
  MODULAR_MONOLITH_COMPONENTS,
  ANTI_CYCLE_RULES,
  LogicalComponent,
} from './data/sgaLogicalArchitectureData';

export default function App() {
  // Main view switcher
  const [mainView, setMainView] = useState<'casos-de-uso' | 'vista-logica'>('vista-logica');

  // State for Casos de Uso view
  const [selectedModule, setSelectedModule] = useState<string>('Todos');
  const [selectedActor, setSelectedActor] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'tabla' | 'tarjetas' | 'matriz' | 'simulador'>('tabla');
  const [selectedUseCase, setSelectedUseCase] = useState<UseCase | null>(SGA_USE_CASES[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [simStep, setSimStep] = useState<number>(0);

  // State for Vista Lógica view
  const [selectedComponentId, setSelectedComponentId] = useState<string>('auth-module');
  const [logicalTab, setLogicalTab] = useState<'componentes' | 'anticycles' | 'dag' | 'rnf'>('componentes');

  // Filtered use cases
  const filteredUseCases = useMemo(() => {
    return SGA_USE_CASES.filter((uc) => {
      const matchModule = selectedModule === 'Todos' || uc.module === selectedModule;
      const matchActor =
        selectedActor === 'Todos' ||
        uc.actor.includes(selectedActor) ||
        uc.primaryActor === selectedActor;
      const matchSearch =
        searchQuery === '' ||
        uc.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        uc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        uc.precondition.toLowerCase().includes(searchQuery.toLowerCase()) ||
        uc.mainFlow.toLowerCase().includes(searchQuery.toLowerCase()) ||
        uc.postcondition.toLowerCase().includes(searchQuery.toLowerCase());

      return matchModule && matchActor && matchSearch;
    });
  }, [selectedModule, selectedActor, searchQuery]);

  const selectedLogicalComp = useMemo(() => {
    return (
      MODULAR_MONOLITH_COMPONENTS.find((c) => c.id === selectedComponentId) ||
      MODULAR_MONOLITH_COMPONENTS[0]
    );
  }, [selectedComponentId]);

  // Generate markdown of logical architecture
  const logicalArchitectureMarkdown = useMemo(() => {
    let md = `# Vista Lógica de Componentes — SGA (Monolito Modular)\n\n`;
    md += `## 1. Módulos del Sistema, Responsabilidades e Interfaces REST\n\n`;

    MODULAR_MONOLITH_COMPONENTS.forEach((c) => {
      md += `### Módulo: ${c.name} (\`${c.id}\`)\n`;
      md += `- **Categoría:** ${c.category}\n`;
      md += `- **Responsabilidad Principal:** ${c.responsibility}\n`;

      if (c.restEndpoints.length > 0) {
        md += `- **Interfaces que expone (API REST):**\n`;
        c.restEndpoints.forEach((ep) => {
          md += `  - \`${ep.method} ${ep.path}\` — ${ep.description} *(Roles: ${ep.rolesAllowed.join(', ')})*\n`;
        });
      } else {
        md += `- **Interfaces que expone:** Capa interna de acceso a datos sin endpoints HTTP REST públicos. Expone contratos de repositorio e interfaces fuertemente tipadas (\`IUserRepository\`, \`IEnrollmentRepository\`, etc.).\n`;
      }

      md += `- **Dependencias Permitidas:**\n`;
      c.allowedDependencies.forEach((ad) => {
        md += `  - -> **${ad.target}**: ${ad.reason} [Tipo: ${ad.couplingType}]\n`;
      });

      md += `- **Dependencias PROHIBIDAS (Reglas Anti-Ciclo):**\n`;
      c.prohibitedDependencies.forEach((pd) => {
        md += `  - ❌ **NO debe depender de ${pd.target}**: ${pd.reasonToPreventCycle}\n`;
      });

      md += `- **Requisitos No Funcionales (RNF) que satisface:**\n`;
      c.nonFunctionalRequirements.forEach((rnf) => {
        md += `  - **[${rnf.category}]** ${rnf.description} *(Meta: ${rnf.metricTarget})*\n`;
      });
      md += `\n---\n\n`;
    });

    md += `## 2. Reglas Anti-Ciclo Estrictas (Grafo Dirigido Acíclico - DAG)\n\n`;
    ANTI_CYCLE_RULES.forEach((r) => {
      md += `### ${r.code}: ${r.rule}\n`;
      md += `- **Prohibición:** ${r.prohibition}\n`;
      md += `- **Consecuencia si se viola:** ${r.consequenceIfBroken}\n\n`;
    });

    return md;
  }, []);

  const handleCopyLogicalMarkdown = () => {
    navigator.clipboard.writeText(logicalArchitectureMarkdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadLogicalMarkdown = () => {
    const blob = new Blob([logicalArchitectureMarkdown], {
      type: 'text/markdown;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'SGA_Vista_Logica_Monolito_Modular.md');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getModuleIcon = (moduleName: string) => {
    switch (moduleName) {
      case 'Autenticación':
      case 'Autenticación / Autorización':
        return <ShieldCheck className="w-4 h-4 text-violet-600 dark:text-violet-400" />;
      case 'Gestión académica':
      case 'Gestión Académica':
        return <GraduationCap className="w-4 h-4 text-blue-600 dark:text-blue-400" />;
      case 'Matrícula':
        return <ClipboardList className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
      case 'Calificaciones':
        return <Award className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
      case 'Reportes':
        return <BarChart3 className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />;
      case 'Auditoría':
        return <FileSearch className="w-4 h-4 text-rose-600 dark:text-rose-400" />;
      case 'Capa de Acceso a Datos (DAL)':
        return <Database className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />;
      default:
        return <FileText className="w-4 h-4 text-slate-600" />;
    }
  };

  const getActorBadgeColor = (actorString: string) => {
    if (actorString.includes('Todos') || actorString.includes(',')) {
      return 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800';
    }
    if (actorString.includes('Administrador')) {
      return 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-300 dark:border-indigo-800';
    }
    if (actorString.includes('Coordinador')) {
      return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800';
    }
    if (actorString.includes('Docente')) {
      return 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800';
    }
    if (actorString.includes('Estudiante')) {
      return 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-800';
    }
    return 'bg-slate-100 text-slate-800 border-slate-200';
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans antialiased">
      {/* Executive Header */}
      <header className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 sticky top-0 z-30 shadow-xs backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-sky-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold tracking-wider uppercase px-2 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  Arquitectura de Software
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  Monolito Modular • Clean Architecture • Bounded Contexts
                </span>
              </div>
              <h1 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                SGA — Sistema de Gestión Académica
              </h1>
            </div>
          </div>

          {/* Main Architectural Views Switcher */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
              <button
                onClick={() => setMainView('vista-logica')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  mainView === 'vista-logica'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                Vista Lógica (Monolito Modular)
              </button>
              <button
                onClick={() => setMainView('casos-de-uso')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  mainView === 'casos-de-uso'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                Casos de Uso (10 CUs)
              </button>
            </div>

            <button
              onClick={handleCopyLogicalMarkdown}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-900 text-white transition-all shadow-xs cursor-pointer active:scale-95"
              title="Copiar especificación arquitectónica en Markdown"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? '¡Copiado!' : 'Copiar Markdown'}
            </button>
            <button
              onClick={handleDownloadLogicalMarkdown}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 transition-all shadow-xs cursor-pointer"
              title="Descargar documento de arquitectura"
            >
              <Download className="w-3.5 h-3.5" />
              .md
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* ========================================================================= */}
        {/* VIEW 1: VISTA LÓGICA DE COMPONENTES (MONOLITO MODULAR)                    */}
        {/* ========================================================================= */}
        {mainView === 'vista-logica' && (
          <div className="space-y-6">
            {/* Architectural Pitch Banner */}
            <section className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-lg border border-indigo-900/50">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-2 max-w-3xl">
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-medium border border-indigo-400/30">
                    <Server className="w-3.5 h-3.5" />
                    Patrón Arquitectónico: Monolito Modular (Modular Monolith)
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                    Vista Lógica de Componentes, Interfaces REST y Control de Ciclos
                  </h2>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    Un único artefacto desplegable con separación estricta de dominios (Bounded Contexts).
                    Cada módulo encapsula su lógica y expone interfaces bien definidas. La persistencia
                    está aislada en la Capa de Acceso a Datos (DAL) y el flujo de llamadas obedece a un
                    <strong> Grafo Dirigido Acíclico (DAG)</strong> con prohibición formal de dependencias circulares.
                  </p>
                </div>

                {/* Quick Architecture Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white/5 p-3 rounded-xl border border-white/10 backdrop-blur-xs">
                  <div className="text-center p-2">
                    <div className="text-2xl font-black text-indigo-300">7</div>
                    <div className="text-xs text-slate-400 font-medium">Módulos Mínimos</div>
                  </div>
                  <div className="text-center p-2">
                    <div className="text-2xl font-black text-emerald-300">24+</div>
                    <div className="text-xs text-slate-400 font-medium">Endpoints REST</div>
                  </div>
                  <div className="text-center p-2">
                    <div className="text-2xl font-black text-rose-300">0</div>
                    <div className="text-xs text-slate-400 font-medium">Ciclos Permitidos</div>
                  </div>
                  <div className="text-center p-2">
                    <div className="text-2xl font-black text-amber-300">ACID</div>
                    <div className="text-xs text-slate-400 font-medium">Atomicidad DAL</div>
                  </div>
                </div>
              </div>

              {/* Module badges */}
              <div className="mt-5 pt-4 border-t border-indigo-900/60 flex flex-wrap items-center gap-2 text-xs">
                <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px] mr-2">
                  Componentes del Monolito:
                </span>
                {MODULAR_MONOLITH_COMPONENTS.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      setSelectedComponentId(c.id);
                      setLogicalTab('componentes');
                    }}
                    className={`px-2.5 py-1 rounded-md font-medium border transition-all cursor-pointer flex items-center gap-1.5 ${
                      selectedComponentId === c.id
                        ? 'bg-indigo-600 text-white border-indigo-400 shadow-xs'
                        : 'bg-white/10 text-slate-200 border-white/10 hover:bg-white/20'
                    }`}
                  >
                    {getModuleIcon(c.name)}
                    <span>{c.name}</span>
                  </button>
                ))}
              </div>
            </section>

            {/* Navigation subtabs inside Vista Lógica */}
            <section className="bg-white dark:bg-slate-900 rounded-xl p-3 shadow-xs border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                <button
                  onClick={() => setLogicalTab('componentes')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                    logicalTab === 'componentes'
                      ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Detalle de Módulos & APIs REST
                </button>
                <button
                  onClick={() => setLogicalTab('dag')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                    logicalTab === 'dag'
                      ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Diagrama de Dependencias (DAG)
                </button>
                <button
                  onClick={() => setLogicalTab('anticycles')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                    logicalTab === 'anticycles'
                      ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Reglas Anti-Ciclo Estrictas ({ANTI_CYCLE_RULES.length})
                </button>
                <button
                  onClick={() => setLogicalTab('rnf')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                    logicalTab === 'rnf'
                      ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Matriz de RNF por Módulo
                </button>
              </div>

              <div className="text-xs text-slate-500 font-mono">
                Módulo activo: <strong className="text-indigo-600">{selectedLogicalComp.name}</strong>
              </div>
            </section>

            {/* TAB: COMPONENTES DETALLE */}
            {logicalTab === 'componentes' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left side: Module Selector Sidebar */}
                <div className="lg:col-span-4 space-y-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1 mb-2">
                    Módulos Arquitectónicos (7)
                  </div>
                  {MODULAR_MONOLITH_COMPONENTS.map((c) => {
                    const isSelected = c.id === selectedComponentId;
                    return (
                      <div
                        key={c.id}
                        onClick={() => setSelectedComponentId(c.id)}
                        className={`p-3.5 rounded-xl border text-xs cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-500 shadow-xs ring-1 ring-indigo-500'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            {getModuleIcon(c.name)}
                            <span className="font-bold text-slate-900 dark:text-white text-sm">
                              {c.name}
                            </span>
                          </div>
                          <span className="text-[10px] px-2 py-0.5 rounded font-mono bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {c.category}
                          </span>
                        </div>
                        <p className="text-slate-500 dark:text-slate-400 line-clamp-2 text-[11px] leading-relaxed">
                          {c.responsibility}
                        </p>
                        <div className="mt-2 flex items-center justify-between text-[11px] font-mono text-slate-400">
                          <span>
                            {c.restEndpoints.length > 0
                              ? `${c.restEndpoints.length} APIs REST`
                              : 'Contratos Internos'}
                          </span>
                          <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                            {c.allowedDependencies.length} dependencias
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Right side: Detailed Module Specification */}
                <div className="lg:col-span-8 space-y-5">
                  <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
                    {/* Header */}
                    <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                            {selectedLogicalComp.packageKey}
                          </span>
                          <span className="text-xs px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {selectedLogicalComp.category}
                          </span>
                        </div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1.5 flex items-center gap-2">
                          {getModuleIcon(selectedLogicalComp.name)}
                          {selectedLogicalComp.name}
                        </h3>
                      </div>
                    </div>

                    {/* Responsabilidad Principal */}
                    <div className="space-y-1.5">
                      <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Responsabilidad Principal
                      </div>
                      <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 leading-relaxed font-medium">
                        {selectedLogicalComp.responsibility}
                      </p>
                    </div>

                    {/* Interfaces que Expone (API REST) */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                          Interfaces que Expone (API REST Pública / Fachada)
                        </div>
                        <span className="text-[11px] font-mono text-slate-400">
                          {selectedLogicalComp.restEndpoints.length} Endpoints
                        </span>
                      </div>

                      {selectedLogicalComp.restEndpoints.length > 0 ? (
                        <div className="space-y-2">
                          {selectedLogicalComp.restEndpoints.map((ep, idx) => {
                            const methodColors = {
                              GET: 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border-blue-200 dark:border-blue-800',
                              POST: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
                              PUT: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-amber-200 dark:border-amber-800',
                              DELETE: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 border-rose-200 dark:border-rose-800',
                            };
                            return (
                              <div
                                key={idx}
                                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                              >
                                <div className="flex items-center gap-2 font-mono">
                                  <span
                                    className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                      methodColors[ep.method]
                                    }`}
                                  >
                                    {ep.method}
                                  </span>
                                  <span className="font-bold text-slate-800 dark:text-slate-200">
                                    {ep.path}
                                  </span>
                                </div>
                                <div className="text-slate-600 dark:text-slate-400 text-[11px] sm:text-right">
                                  <span>{ep.description}</span>
                                  <div className="text-[10px] text-slate-400">
                                    Roles: <strong>{ep.rolesAllowed.join(', ')}</strong>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-2">
                          <div className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                            <Database className="w-4 h-4 text-indigo-600" />
                            Capa de Persistencia Interna (Sin API REST Pública HTTP)
                          </div>
                          <p className="text-slate-600 dark:text-slate-400">
                            En un monolito modular, la <strong>Capa de Acceso a Datos (DAL)</strong> no
                            expone endpoints HTTP hacia el cliente exterior. En su lugar, expone contratos de
                            repositorio tipados e interfaces de inyección de dependencias para los servicios de
                            los módulos de negocio.
                          </p>
                          <div className="font-mono text-[11px] space-y-1 text-indigo-700 dark:text-indigo-400 bg-white dark:bg-slate-900 p-2 rounded border border-slate-200 dark:border-slate-800">
                            {selectedLogicalComp.internalInterfaces?.map((ii, i) => (
                              <div key={i}>• {ii}</div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Dependencias Permitidas vs Prohibidas */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Permitidas */}
                      <div className="p-4 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50 space-y-2">
                        <div className="font-bold text-emerald-900 dark:text-emerald-300 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                          <CheckSquare className="w-4 h-4 text-emerald-600" />
                          Dependencias Permitidas
                        </div>
                        <div className="space-y-2 text-xs">
                          {selectedLogicalComp.allowedDependencies.map((ad, i) => (
                            <div
                              key={i}
                              className="p-2 rounded bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900/40 space-y-1"
                            >
                              <div className="font-semibold text-slate-900 dark:text-slate-100 flex items-center justify-between">
                                <span>→ {ad.target}</span>
                                <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-mono">
                                  {ad.couplingType}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-600 dark:text-slate-400">
                                {ad.reason}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Prohibidas */}
                      <div className="p-4 rounded-xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/50 space-y-2">
                        <div className="font-bold text-rose-900 dark:text-rose-300 text-xs flex items-center gap-1.5 uppercase tracking-wider">
                          <XCircle className="w-4 h-4 text-rose-600" />
                          Dependencias PROHIBIDAS (Anti-Ciclos)
                        </div>
                        <div className="space-y-2 text-xs">
                          {selectedLogicalComp.prohibitedDependencies.map((pd, i) => (
                            <div
                              key={i}
                              className="p-2 rounded bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/40 space-y-1"
                            >
                              <div className="font-semibold text-rose-700 dark:text-rose-400">
                                ❌ {pd.target}
                              </div>
                              <p className="text-[11px] text-slate-600 dark:text-slate-400">
                                {pd.reasonToPreventCycle}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Requisitos No Funcionales (RNF) */}
                    <div className="space-y-2">
                      <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                        Requisitos No Funcionales (RNF) que Satisface
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        {selectedLogicalComp.nonFunctionalRequirements.map((rnf, i) => (
                          <div
                            key={i}
                            className="p-3 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900/40 space-y-1"
                          >
                            <span className="font-bold text-indigo-700 dark:text-indigo-300 text-[11px] uppercase tracking-wider">
                              [{rnf.category}]
                            </span>
                            <p className="text-slate-700 dark:text-slate-300 font-medium">
                              {rnf.description}
                            </p>
                            <div className="text-[11px] text-slate-500 font-mono">
                              Meta: <strong>{rnf.metricTarget}</strong>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: DIAGRAMA DAG */}
            {logicalTab === 'dag' && (
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Network className="w-5 h-5 text-indigo-600" />
                    Topología del Grafo Dirigido Acíclico (DAG) del Monolito Modular
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Visualización de los flujos de invocación permitidos. Las flechas representan dependencias
                    unidireccionales hacia abajo. Ninguna flecha regresa hacia arriba, garantizando ausencia total de ciclos.
                  </p>
                </div>

                {/* Visual Architecture Hierarchy */}
                <div className="bg-slate-900 text-white p-6 rounded-xl space-y-6 font-mono text-xs border border-slate-800">
                  {/* Layer 1: Edge Security */}
                  <div className="space-y-2">
                    <div className="text-violet-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4" />
                      Capa 1: Puerta de Entrada & Seguridad Transversal
                    </div>
                    <div className="p-3 bg-violet-950/40 border border-violet-800/60 rounded-lg flex items-center justify-between">
                      <span className="font-bold">Módulo Autenticación / Autorización (JWT / RBAC)</span>
                      <span className="text-slate-400 text-[10px]">Expone AuthGuard & Contexto</span>
                    </div>
                  </div>

                  <div className="flex justify-center text-slate-500">
                    <span className="text-lg">↓ Inyecta credenciales / autoriza roles</span>
                  </div>

                  {/* Layer 2: Core Domain Master */}
                  <div className="space-y-2">
                    <div className="text-blue-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                      <GraduationCap className="w-4 h-4" />
                      Capa 2: Maestro de Dominio Académico (Planeación)
                    </div>
                    <div className="p-3 bg-blue-950/40 border border-blue-800/60 rounded-lg flex items-center justify-between">
                      <span className="font-bold">Módulo Gestión Académica (Períodos, Catálogo, Oferta, Docentes)</span>
                      <span className="text-slate-400 text-[10px]">Provee AcademicCatalogService</span>
                    </div>
                  </div>

                  <div className="flex justify-around text-slate-500">
                    <span>↙ Valida horarios y cupos</span>
                    <span>↘ Valida escalas y cursos</span>
                  </div>

                  {/* Layer 3: Transactional Services */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="text-emerald-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                        <ClipboardList className="w-4 h-4" />
                        Capa 3A: Inscripción Transaccional
                      </div>
                      <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg space-y-1">
                        <div className="font-bold">Módulo Matrícula</div>
                        <div className="text-[10px] text-slate-400">
                          Reserva atómica de cupos • SELECT FOR UPDATE
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-amber-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                        <Award className="w-4 h-4" />
                        Capa 3B: Asentamiento de Evaluación
                      </div>
                      <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-lg space-y-1">
                        <div className="font-bold">Módulo Calificaciones</div>
                        <div className="text-[10px] text-slate-400">
                          Lee estudiantes inscritos desde Matrícula (solo lectura)
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-center text-slate-500">
                    <span className="text-lg">↓ Alimenta promedios y métricas de desempeño</span>
                  </div>

                  {/* Layer 4: Analytics Sink */}
                  <div className="space-y-2">
                    <div className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex items-center gap-2">
                      <BarChart3 className="w-4 h-4" />
                      Capa 4: Nodo Hoja Analítico (Read-Only Consumer)
                    </div>
                    <div className="p-3 bg-cyan-950/40 border border-cyan-800/60 rounded-lg flex items-center justify-between">
                      <span className="font-bold">Módulo Reportes (Estadísticas, Deserción, Ocupación)</span>
                      <span className="text-slate-400 text-[10px]">Ningún módulo de negocio depende de él</span>
                    </div>
                  </div>

                  {/* Transversals */}
                  <div className="pt-4 border-t border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded-lg space-y-1">
                      <div className="text-rose-400 font-bold text-[11px] flex items-center gap-1.5">
                        <FileSearch className="w-3.5 h-3.5" />
                        Soporte Transversal: Módulo Auditoría
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Receptor pasivo desacoplado mediante bus de eventos. Almacenamiento WORM inmutable.
                      </p>
                    </div>

                    <div className="p-3 bg-indigo-950/30 border border-indigo-800/40 rounded-lg space-y-1">
                      <div className="text-indigo-400 font-bold text-[11px] flex items-center gap-1.5">
                        <Database className="w-3.5 h-3.5" />
                        Capa Base de Persistencia: Capa de Acceso a Datos (DAL)
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Invocada por todos los módulos hacia abajo. Cero dependencias hacia capas superiores.
                      </p>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* TAB: REGLAS ANTI-CICLO */}
            {logicalTab === 'anticycles' && (
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <AlertOctagon className="w-5 h-5 text-rose-600" />
                    Reglas Anti-Ciclo Estrictas (Prevención de Dependencias Circulares)
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    En una arquitectura monolítica modular, las dependencias circulares provocan fallos en tiempo
                    de compilación, deadlocks en inyección de dependencias (Spring/NestJS) e imposibilitan la futura
                    extracción a microservicios si fuera requerido.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {ANTI_CYCLE_RULES.map((rule) => (
                    <div
                      key={rule.code}
                      className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900">
                          {rule.code}
                        </span>
                        <span className="font-bold text-slate-900 dark:text-white">{rule.rule}</span>
                      </div>
                      <div className="p-2.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/60 font-mono text-[11px] text-rose-700 dark:text-rose-400">
                        Prohibición: {rule.prohibition}
                      </div>
                      <p className="text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
                        <strong>Impacto si se viola:</strong> {rule.consequenceIfBroken}
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* TAB: MATRIZ DE RNF */}
            {logicalTab === 'rnf' && (
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Zap className="w-5 h-5 text-amber-500" />
                    Matriz de Requisitos No Funcionales (RNF) Satisfechos por Componente
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Mapeo de estándares de calidad según ISO/IEC 25010 (Seguridad, Desempeño, Consistencia, Auditabilidad).
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border border-slate-200 dark:border-slate-700">
                    <thead>
                      <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                        <th className="p-3 border-r border-slate-200 dark:border-slate-700 w-44">Módulo</th>
                        <th className="p-3 border-r border-slate-200 dark:border-slate-700 w-32">Dimensión RNF</th>
                        <th className="p-3 border-r border-slate-200 dark:border-slate-700">Estrategia Arquitectónica</th>
                        <th className="p-3 w-48">Métrica Objetivo</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                      {MODULAR_MONOLITH_COMPONENTS.flatMap((c) =>
                        c.nonFunctionalRequirements.map((rnf, idx) => (
                          <tr key={`${c.id}-${idx}`} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                            {idx === 0 && (
                              <td
                                rowSpan={c.nonFunctionalRequirements.length}
                                className="p-3 font-bold text-slate-900 dark:text-white border-r border-slate-200 dark:border-slate-700 align-top bg-slate-50/50 dark:bg-slate-800/20"
                              >
                                <div className="flex items-center gap-1.5">
                                  {getModuleIcon(c.name)}
                                  <span>{c.name}</span>
                                </div>
                              </td>
                            )}
                            <td className="p-3 font-semibold text-indigo-600 dark:text-indigo-400 border-r border-slate-200 dark:border-slate-700">
                              {rnf.category}
                            </td>
                            <td className="p-3 text-slate-700 dark:text-slate-300 border-r border-slate-200 dark:border-slate-700 leading-relaxed">
                              {rnf.description}
                            </td>
                            <td className="p-3 font-mono text-[11px] text-slate-600 dark:text-slate-400">
                              {rnf.metricTarget}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </section>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: CASOS DE USO PRINCIPALES (10 CUs)                                */}
        {/* ========================================================================= */}
        {mainView === 'casos-de-uso' && (
          <div className="space-y-6">
            {/* View Selection & Search Controls */}
            <section className="bg-white dark:bg-slate-900 rounded-xl p-4 shadow-xs border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
              {/* Navigation Tabs */}
              <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg overflow-x-auto">
                <button
                  onClick={() => setActiveTab('tabla')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'tabla'
                      ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Formato Tabla (10 CUs)
                </button>
                <button
                  onClick={() => setActiveTab('tarjetas')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'tarjetas'
                      ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Tarjetas Detalladas ({filteredUseCases.length})
                </button>
                <button
                  onClick={() => setActiveTab('matriz')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'matriz'
                      ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Matriz Actores vs Módulos
                </button>
                <button
                  onClick={() => setActiveTab('simulador')}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'simulador'
                      ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Simulador de Flujo Paso a Paso
                </button>
              </div>

              {/* Search bar */}
              <div className="relative min-w-[240px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar caso de uso..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </section>

            {/* TAB 1: EXACT REQUESTED TABLE VIEW */}
            {activeTab === 'tabla' && (
              <section className="bg-white dark:bg-slate-900 rounded-2xl shadow-xs border border-slate-200 dark:border-slate-800 overflow-hidden">
                <div className="p-4 bg-slate-50/70 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <FileText className="w-4 h-4 text-indigo-600" />
                      Tabla de Casos de Uso Principales (Máximo 10)
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Actor, Precondición, Flujo Principal Resumido y Postcondición para los 4 actores y 6 módulos.
                    </p>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 font-semibold">
                    10 de 10 Casos de Uso
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-100/90 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold uppercase tracking-wider text-[11px] border-b border-slate-200 dark:border-slate-700">
                        <th className="py-3 px-3 w-16 text-center">ID</th>
                        <th className="py-3 px-4 min-w-[190px]">Caso de Uso / Módulo</th>
                        <th className="py-3 px-4 min-w-[150px]">Actor Principal</th>
                        <th className="py-3 px-4 min-w-[200px]">Precondición</th>
                        <th className="py-3 px-4 min-w-[320px]">Flujo Principal Resumido</th>
                        <th className="py-3 px-4 min-w-[220px]">Postcondición</th>
                        <th className="py-3 px-3 text-center w-16">Acción</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                      {filteredUseCases.map((uc) => (
                        <tr
                          key={uc.id}
                          className="hover:bg-indigo-50/40 dark:hover:bg-slate-800/40 transition-colors group cursor-pointer"
                          onClick={() => {
                            setSelectedUseCase(uc);
                            setSimStep(0);
                          }}
                        >
                          <td className="py-3.5 px-3 text-center font-mono font-bold text-indigo-700 dark:text-indigo-400">
                            {uc.id}
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-bold text-slate-900 dark:text-slate-100 text-[13px] group-hover:text-indigo-600 transition-colors">
                              {uc.title}
                            </div>
                            <div className="inline-flex items-center gap-1 mt-1 text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                              {getModuleIcon(uc.module)}
                              <span>{uc.module}</span>
                            </div>
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className={`inline-block px-2 py-0.5 rounded-md text-[11px] font-semibold border ${getActorBadgeColor(
                                uc.actor
                              )}`}
                            >
                              {uc.actor}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 leading-relaxed">
                            {uc.precondition}
                          </td>
                          <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 leading-relaxed">
                            <div className="bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700/60 font-mono text-[11px] text-slate-800 dark:text-slate-200">
                              {uc.mainFlow}
                            </div>
                          </td>
                          <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 leading-relaxed">
                            <span className="flex items-start gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{uc.postcondition}</span>
                            </span>
                          </td>
                          <td className="py-3.5 px-3 text-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedUseCase(uc);
                                setActiveTab('simulador');
                                setSimStep(0);
                              }}
                              className="p-1.5 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-slate-800 transition-all cursor-pointer"
                              title="Ver flujo detallado en simulador"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            {/* TAB 2: DETAILED CARDS VIEW */}
            {activeTab === 'tarjetas' && (
              <section className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {filteredUseCases.map((uc) => (
                  <div
                    key={uc.id}
                    className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-indigo-300 dark:hover:border-indigo-700 transition-all flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border border-slate-200 dark:border-slate-700">
                            {uc.id}
                          </span>
                          <span className="text-xs px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center gap-1 border border-slate-200 dark:border-slate-700 font-medium">
                            {getModuleIcon(uc.module)}
                            {uc.module}
                          </span>
                        </div>
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded-md border ${getActorBadgeColor(
                            uc.actor
                          )}`}
                        >
                          {uc.actor}
                        </span>
                      </div>

                      <h4 className="text-base font-bold text-slate-900 dark:text-white">{uc.title}</h4>

                      <div className="text-xs space-y-1">
                        <div className="font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-[10px]">
                          Precondición
                        </div>
                        <p className="text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                          {uc.precondition}
                        </p>
                      </div>

                      <div className="text-xs space-y-1">
                        <div className="font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-[10px]">
                          Flujo Principal Resumido
                        </div>
                        <p className="text-slate-800 dark:text-slate-200 bg-indigo-50/50 dark:bg-indigo-950/20 p-2.5 rounded-lg border border-indigo-100 dark:border-indigo-900/40 font-mono text-[11px] leading-relaxed">
                          {uc.mainFlow}
                        </p>
                      </div>

                      <div className="text-xs space-y-1">
                        <div className="font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-[10px]">
                          Postcondición
                        </div>
                        <p className="text-slate-700 dark:text-slate-300 flex items-start gap-1.5 bg-emerald-50/40 dark:bg-emerald-950/20 p-2.5 rounded-lg border border-emerald-100 dark:border-emerald-900/40">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{uc.postcondition}</span>
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-[11px] text-slate-400 font-mono">
                        Criticidad: <strong className="text-indigo-600">{uc.criticality}</strong>
                      </span>
                      <button
                        onClick={() => {
                          setSelectedUseCase(uc);
                          setActiveTab('simulador');
                          setSimStep(0);
                        }}
                        className="inline-flex items-center gap-1 font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                      >
                        Simular Flujo <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </section>
            )}

            {/* TAB 3: MATRIX */}
            {activeTab === 'matriz' && (
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-xs border border-slate-200 dark:border-slate-800 space-y-6">
                <div>
                  <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                    <Layers className="w-5 h-5 text-indigo-600" />
                    Matriz de Trazabilidad: Actores vs Módulos
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Mapeo formal de responsabilidades entre los 4 actores y los 6 módulos funcionales.
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border border-slate-200 dark:border-slate-700">
                    <thead>
                      <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                        <th className="p-3 border-r border-slate-200 dark:border-slate-700 w-44">Módulo SGA</th>
                        {SGA_ACTORS.map((act) => (
                          <th
                            key={act.id}
                            className="p-3 border-r border-slate-200 dark:border-slate-700 text-center font-bold"
                          >
                            {act.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                      {SGA_MODULES.map((mod) => (
                        <tr key={mod.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                          <td className="p-3 font-semibold text-slate-900 dark:text-white border-r border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/30">
                            <div className="flex items-center gap-2">
                              {getModuleIcon(mod.name)}
                              <span>{mod.name}</span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-normal mt-0.5">{mod.description}</div>
                          </td>
                          {SGA_ACTORS.map((act) => {
                            const matchingUCs = SGA_USE_CASES.filter(
                              (uc) =>
                                uc.module === mod.id &&
                                (uc.actor.includes(act.id) || uc.primaryActor === act.id)
                            );
                            return (
                              <td
                                key={act.id}
                                className="p-3 border-r border-slate-200 dark:border-slate-700 align-top text-center"
                              >
                                {matchingUCs.length > 0 ? (
                                  <div className="space-y-1.5 flex flex-col items-center">
                                    {matchingUCs.map((uc) => (
                                      <div
                                        key={uc.id}
                                        className="px-2 py-1 rounded bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 text-[11px] font-medium w-full text-left"
                                      >
                                        <span className="font-bold">{uc.id}: </span>
                                        <span>{uc.title}</span>
                                      </div>
                                    ))}
                                  </div>
                                ) : (
                                  <span className="text-slate-300 dark:text-slate-700 text-sm font-mono">—</span>
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            {/* TAB 4: SIMULATOR */}
            {activeTab === 'simulador' && selectedUseCase && (
              <section className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-xs border border-slate-200 dark:border-slate-800 space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold px-2.5 py-0.5 rounded-md bg-indigo-600 text-white">
                        {selectedUseCase.id}
                      </span>
                      <span className="text-xs px-2.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                        {getModuleIcon(selectedUseCase.module)}
                        Módulo: {selectedUseCase.module}
                      </span>
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded-md font-semibold border ${getActorBadgeColor(
                          selectedUseCase.actor
                        )}`}
                      >
                        Actor: {selectedUseCase.actor}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">{selectedUseCase.title}</h3>
                  </div>

                  <select
                    value={selectedUseCase.id}
                    onChange={(e) => {
                      const found = SGA_USE_CASES.find((u) => u.id === e.target.value);
                      if (found) {
                        setSelectedUseCase(found);
                        setSimStep(0);
                      }
                    }}
                    className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                  >
                    {SGA_USE_CASES.map((uc) => (
                      <option key={uc.id} value={uc.id}>
                        {uc.id}: {uc.title} ({uc.module})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Steps */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {selectedUseCase.steps.map((st, idx) => (
                    <div
                      key={st.step}
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs bg-slate-50 dark:bg-slate-800/40"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] bg-indigo-600 text-white">
                          {st.step}
                        </span>
                        <span className="text-[10px] font-semibold text-slate-500">{st.actor}</span>
                      </div>
                      <p className="text-slate-800 dark:text-slate-200 font-medium leading-relaxed">
                        {st.action}
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}

        {/* Global Footer */}
        <footer className="text-center py-6 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 space-y-1">
          <p className="font-semibold text-slate-700 dark:text-slate-400">
            SGA — Arquitectura de Software Monolítica Modular
          </p>
          <p className="text-[11px]">
            Diseñado conforme a estándares de Clean Architecture, Domain-Driven Design (DDD Bounded Contexts) e ISO 25010.
          </p>
        </footer>
      </main>
    </div>
  );
}
