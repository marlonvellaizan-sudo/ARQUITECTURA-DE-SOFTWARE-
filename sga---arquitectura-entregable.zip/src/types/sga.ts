export type RolUsuario = 'Administrador' | 'Coordinador' | 'Docente' | 'Estudiante';

export interface Usuario {
  id: string;
  nombre: string;
  email: string;
  rol: RolUsuario;
  avatar?: string;
  codigoIdentificacion: string;
  programaId?: string; // Para estudiantes o coordinadores
}

export interface Programa {
  id: string;
  codigo: string;
  nombre: string;
  facultad: string;
  activo: boolean;
}

export interface Asignatura {
  id: string;
  codigo: string;
  nombre: string;
  creditos: number;
  programaId: string;
  periodo: string;
  activo: boolean;
}

export interface Grupo {
  id: string;
  asignaturaId: string;
  numeroGrupo: string;
  docenteId: string; // ID del docente
  horario: string;
  aula: string;
  cupoMaximo: number;
  cupoDisponible: number;
  periodo: string;
  activo: boolean;
}

export interface Matricula {
  id: string;
  estudianteId: string;
  grupoId: string;
  asignaturaId: string;
  periodo: string;
  fechaMatricula: string;
  estado: 'Activa' | 'Cancelada';
}

export interface Calificacion {
  id: string;
  matriculaId: string;
  estudianteId: string;
  grupoId: string;
  asignaturaId: string;
  corte1?: number; // 30%
  corte2?: number; // 30%
  corte3?: number; // 40% (Examen Final)
  definitiva?: number;
  observaciones?: string;
  fechaActualizacion: string;
  actualizadoPor: string;
}

export interface RegistroAuditoria {
  id: string;
  fechaHora: string;
  usuarioId: string;
  usuarioNombre: string;
  rol: RolUsuario;
  modulo: 'Autenticación' | 'Gestión Académica' | 'Matrícula' | 'Calificaciones' | 'Reportes' | 'Auditoría';
  accion: string;
  detalle: string;
  ip?: string;
}

export interface DocenteData {
  id: string;
  usuarioId: string;
  nombre: string;
  email: string;
  especialidad: string;
  activo: boolean;
}

export interface EstudianteData {
  id: string;
  usuarioId: string;
  nombre: string;
  email: string;
  codigoEstudiante: string;
  programaId: string;
  semestreActual: number;
  activo: boolean;
}
