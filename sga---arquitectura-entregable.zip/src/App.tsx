import React, { useState } from 'react';
import { SGAProvider, useSGA } from './context/SGAContext';
import { RolUsuario } from './types/sga';
import { GestionAcademica } from './components/GestionAcademica';
import { MatriculaEstudiante } from './components/MatriculaEstudiante';
import { CalificacionesModulo } from './components/CalificacionesModulo';
import { ReportesModulo } from './components/ReportesModulo';
import { AuditoriaModulo } from './components/AuditoriaModulo';
import { LoginModal } from './components/LoginModal';

// Icons
import {
  ShieldCheck,
  GraduationCap,
  ClipboardList,
  Award,
  BarChart3,
  FileSearch,
  User,
  LogOut,
  LogIn,
  Layers,
  Server,
  Cpu,
  FileText,
  Sparkles,
  ChevronRight,
  Database,
  Lock,
} from 'lucide-react';

// Architectural reference data
import { SGA_ACTORS, SGA_MODULES, SGA_USE_CASES } from './data/sgaArchitectureData';
import { MODULAR_MONOLITH_COMPONENTS, ANTI_CYCLE_RULES } from './data/sgaLogicalArchitectureData';

function InnerApp() {
  const { usuarioActual, loginRapido, logout } = useSGA();

  // Mode: "sistema-vivo" (Functional SGA) vs "arquitectura" (Architecture specification)
  const [modoApp, setModoApp] = useState<'sistema-vivo' | 'arquitectura'>('sistema-vivo');

  // Subtab for functional SGA
  const [activeModule, setActiveModule] = useState<'gestion' | 'matricula' | 'calificaciones' | 'reportes' | 'auditoria'>(
    usuarioActual?.rol === 'Estudiante' ? 'matricula' : 'gestion'
  );

  // Subtab for architecture view
  const [archTab, setArchTab] = useState<'casos-de-uso' | 'vista-logica'>('casos-de-uso');

  // Login Modal
  const [loginModalOpen, setLoginModalOpen] = useState(false);

  // Synchronize default module if role changes
  const handleCambiarRolRapido = (rol: RolUsuario) => {
    loginRapido(rol);
    if (rol === 'Estudiante') {
      setActiveModule('matricula');
    } else if (rol === 'Docente') {
      setActiveModule('calificaciones');
    } else {
      setActiveModule('gestion');
    }
  };

  // RBAC: Check which modules are permitted for the current user
  const rol = usuarioActual?.rol || 'Estudiante';
  const puedeVerGestion = rol === 'Administrador' || rol === 'Coordinador';
  const puedeVerMatricula = rol === 'Estudiante' || rol === 'Administrador';
  const puedeVerCalificaciones = true; // All roles have appropriate view
  const puedeVerReportes = rol === 'Administrador' || rol === 'Coordinador';
  const puedeVerAuditoria = rol === 'Administrador';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans antialiased flex flex-col">
      {/* 1. TOP GLOBAL NAVBAR */}
      <header className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 sticky top-0 z-40 shadow-xs backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-sky-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                  SGA Institucional
                </span>
                <span className="text-[11px] text-slate-400 hidden sm:inline">
                  Sistema de Gestión Académica
                </span>
              </div>
              <h1 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-tight">
                Plataforma Académica Integral
              </h1>
            </div>
          </div>

          {/* Mode Switcher: Live System vs Architecture */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
            <button
              onClick={() => setModoApp('sistema-vivo')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                modoApp === 'sistema-vivo'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Sistema Funcional (En Vivo)</span>
            </button>
            <button
              onClick={() => setModoApp('arquitectura')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                modoApp === 'arquitectura'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              <span>Doc. Arquitectura (10 CUs & DAG)</span>
            </button>
          </div>

          {/* User profile / Login */}
          <div className="flex items-center gap-2">
            {usuarioActual ? (
              <div className="flex items-center gap-2.5 bg-slate-100 dark:bg-slate-800/80 px-3 py-1 rounded-xl border border-slate-200 dark:border-slate-700">
                <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs uppercase shadow-xs">
                  {usuarioActual.nombre.charAt(0)}
                </div>
                <div className="text-left leading-tight hidden sm:block">
                  <div className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[130px]">
                    {usuarioActual.nombre}
                  </div>
                  <span
                    className={`inline-block text-[10px] font-bold px-1.5 py-0.2 rounded ${
                      usuarioActual.rol === 'Administrador'
                        ? 'bg-indigo-100 text-indigo-700'
                        : usuarioActual.rol === 'Coordinador'
                        ? 'bg-emerald-100 text-emerald-700'
                        : usuarioActual.rol === 'Docente'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-sky-100 text-sky-800'
                    }`}
                  >
                    {usuarioActual.rol}
                  </span>
                </div>
                <button
                  onClick={logout}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
                  title="Cerrar sesión"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setLoginModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer shadow-xs"
              >
                <LogIn className="w-3.5 h-3.5" />
                Iniciar Sesión
              </button>
            )}
          </div>
        </div>
      </header>

      {/* 2. SUBBAR: 1-CLICK ROLE SIMULATOR (RBAC FAST SWITCHER) */}
      <div className="bg-slate-100/80 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800/80 py-2 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-500 font-semibold text-[11px] uppercase tracking-wider flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
              Simular Rol (1 Clic):
            </span>
            <button
              onClick={() => handleCambiarRolRapido('Administrador')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                usuarioActual?.rol === 'Administrador'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>👑 Administrador</span>
            </button>
            <button
              onClick={() => handleCambiarRolRapido('Coordinador')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                usuarioActual?.rol === 'Coordinador'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>📋 Coordinador</span>
            </button>
            <button
              onClick={() => handleCambiarRolRapido('Docente')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                usuarioActual?.rol === 'Docente'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>🎓 Docente</span>
            </button>
            <button
              onClick={() => handleCambiarRolRapido('Estudiante')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                usuarioActual?.rol === 'Estudiante'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>🎒 Estudiante</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 font-mono hidden md:block">
            Modo RBAC Activo: <strong className="text-indigo-600">{usuarioActual?.rol || 'Visitante'}</strong>
          </div>
        </div>
      </div>

      {/* 3. MAIN CONTENT CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full space-y-6">
        {/* ==================================================================== */}
        {/* VIEW A: MODO SISTEMA FUNCIONAL EN VIVO (RBAC MODULE TABS)             */}
        {/* ==================================================================== */}
        {modoApp === 'sistema-vivo' && (
          <div className="space-y-6">
            {/* Functional Module Navigation Tabs (Filtered by RBAC) */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-2.5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 flex-wrap">
                {/* 1. Gestión Académica (Admin / Coordinador) */}
                {puedeVerGestion && (
                  <button
                    onClick={() => setActiveModule('gestion')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      activeModule === 'gestion'
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <GraduationCap className="w-4 h-4" />
                    Gestión Académica
                  </button>
                )}

                {/* 2. Matrícula (Estudiante) */}
                {puedeVerMatricula && (
                  <button
                    onClick={() => setActiveModule('matricula')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      activeModule === 'matricula'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <ClipboardList className="w-4 h-4" />
                    Matrícula Académica
                  </button>
                )}

                {/* 3. Calificaciones (Todos según su alcance) */}
                {puedeVerCalificaciones && (
                  <button
                    onClick={() => setActiveModule('calificaciones')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      activeModule === 'calificaciones'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Award className="w-4 h-4" />
                    {usuarioActual?.rol === 'Estudiante' ? 'Mis Calificaciones' : 'Calificaciones'}
                  </button>
                )}

                {/* 4. Reportes (Admin / Coordinador) */}
                {puedeVerReportes && (
                  <button
                    onClick={() => setActiveModule('reportes')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      activeModule === 'reportes'
                        ? 'bg-cyan-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <BarChart3 className="w-4 h-4" />
                    Reportes
                  </button>
                )}

                {/* 5. Auditoría (Admin) */}
                {puedeVerAuditoria && (
                  <button
                    onClick={() => setActiveModule('auditoria')}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      activeModule === 'auditoria'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <FileSearch className="w-4 h-4" />
                    Auditoría
                  </button>
                )}
              </div>

              <div className="text-[11px] text-slate-400 font-mono px-2">
                Persistencia: <strong>localStorage (BD Local)</strong>
              </div>
            </div>

            {/* Render Selected Module */}
            {activeModule === 'gestion' && puedeVerGestion && <GestionAcademica />}
            {activeModule === 'matricula' && puedeVerMatricula && <MatriculaEstudiante />}
            {activeModule === 'calificaciones' && puedeVerCalificaciones && <CalificacionesModulo />}
            {activeModule === 'reportes' && puedeVerReportes && <ReportesModulo />}
            {activeModule === 'auditoria' && puedeVerAuditoria && <AuditoriaModulo />}
          </div>
        )}

        {/* ==================================================================== */}
        {/* VIEW B: MODO DOCUMENTACIÓN ARQUITECTÓNICA (10 CUs Y MONOLITO MODULAR) */}
        {/* ==================================================================== */}
        {modoApp === 'arquitectura' && (
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-xl p-3 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setArchTab('casos-de-uso')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                    archTab === 'casos-de-uso'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  Tabla de Casos de Uso (10 CUs)
                </button>
                <button
                  onClick={() => setArchTab('vista-logica')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                    archTab === 'vista-logica'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  Vista Lógica (Monolito Modular & DAG)
                </button>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                Especificación Formal Arquitectónica
              </span>
            </div>

            {/* Sub-view: Casos de Uso */}
            {archTab === 'casos-de-uso' && (
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Especificación de los 10 Casos de Uso Principales (SGA)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Estructurados bajo los 4 actores y 6 módulos solicitados.
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-100/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700 uppercase tracking-wider text-[11px]">
                        <th className="p-3 text-center w-16">ID</th>
                        <th className="p-3 min-w-[180px]">Caso de Uso / Módulo</th>
                        <th className="p-3 min-w-[140px]">Actor</th>
                        <th className="p-3 min-w-[200px]">Precondición</th>
                        <th className="p-3 min-w-[320px]">Flujo Principal Resumido</th>
                        <th className="p-3 min-w-[200px]">Postcondición</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                      {SGA_USE_CASES.map((uc) => (
                        <tr key={uc.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                          <td className="p-3 text-center font-mono font-bold text-indigo-600">
                            {uc.id}
                          </td>
                          <td className="p-3">
                            <div className="font-bold text-slate-900 dark:text-white">{uc.title}</div>
                            <span className="text-[10px] text-slate-400 font-medium">{uc.module}</span>
                          </td>
                          <td className="p-3 font-semibold text-slate-700 dark:text-slate-300">
                            {uc.actor}
                          </td>
                          <td className="p-3 text-slate-600 dark:text-slate-400">{uc.precondition}</td>
                          <td className="p-3 text-slate-700 dark:text-slate-300 font-mono text-[11px] leading-relaxed">
                            {uc.mainFlow}
                          </td>
                          <td className="p-3 text-slate-600 dark:text-slate-400">{uc.postcondition}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Sub-view: Vista Lógica */}
            {archTab === 'vista-logica' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {MODULAR_MONOLITH_COMPONENTS.map((comp) => (
                    <div
                      key={comp.id}
                      className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                          {comp.packageKey}
                        </span>
                        <span className="text-[10px] text-slate-400 font-semibold">{comp.category}</span>
                      </div>
                      <h4 className="text-base font-bold text-slate-900 dark:text-white">{comp.name}</h4>
                      <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                        {comp.responsibility}
                      </p>
                      <div className="space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                        <div className="font-semibold text-slate-700 dark:text-slate-300">Endpoints REST:</div>
                        {comp.restEndpoints.map((ep, i) => (
                          <div key={i} className="font-mono text-[11px] text-slate-500">
                            <strong>{ep.method}</strong> {ep.path}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* 4. GLOBAL FOOTER */}
      <footer className="text-center py-5 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 bg-white dark:bg-slate-900">
        <p className="font-semibold text-slate-700 dark:text-slate-400">
          Sistema de Gestión Académica (SGA) — Arquitectura y Aplicación Web Funcional
        </p>
        <p className="text-[11px] text-slate-400 mt-0.5">
          Roles: <strong>Administrador</strong>, <strong>Coordinador</strong>, <strong>Docente</strong>, <strong>Estudiante</strong> • Módulos: <strong>Autenticación</strong>, <strong>Gestión Académica</strong>, <strong>Matrícula</strong>, <strong>Calificaciones</strong>, <strong>Reportes</strong>, <strong>Auditoría</strong>.
        </p>
      </footer>

      {/* Login Modal */}
      <LoginModal isOpen={loginModalOpen} onClose={() => setLoginModalOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <SGAProvider>
      <InnerApp />
    </SGAProvider>
  );
}
