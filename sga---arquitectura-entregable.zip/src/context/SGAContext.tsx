import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Usuario,
  RolUsuario,
  Programa,
  Asignatura,
  Grupo,
  Matricula,
  Calificacion,
  RegistroAuditoria,
  DocenteData,
  EstudianteData,
} from '../types/sga';

interface SGAContextType {
  usuarioActual: Usuario | null;
  login: (email: string, rol?: RolUsuario) => boolean;
  loginRapido: (rol: RolUsuario) => void;
  logout: () => void;

  // Programas
  programas: Programa[];
  crearPrograma: (programa: Omit<Programa, 'id'>) => void;
  editarPrograma: (programa: Programa) => void;
  toggleProgramaActivo: (id: string) => void;

  // Asignaturas
  asignaturas: Asignatura[];
  crearAsignatura: (asignatura: Omit<Asignatura, 'id'>) => void;
  editarAsignatura: (asignatura: Asignatura) => void;
  toggleAsignaturaActiva: (id: string) => void;

  // Docentes
  docentes: DocenteData[];
  crearDocente: (docente: Omit<DocenteData, 'id' | 'usuarioId'>) => void;
  editarDocente: (docente: DocenteData) => void;
  toggleDocenteActivo: (id: string) => void;

  // Estudiantes
  estudiantes: EstudianteData[];
  crearEstudiante: (estudiante: Omit<EstudianteData, 'id' | 'usuarioId'>) => void;
  editarEstudiante: (estudiante: EstudianteData) => void;
  toggleEstudianteActivo: (id: string) => void;

  // Grupos
  grupos: Grupo[];
  crearGrupo: (grupo: Omit<Grupo, 'id' | 'cupoDisponible'>) => void;
  editarGrupo: (grupo: Grupo) => void;
  toggleGrupoActivo: (id: string) => void;

  // Matrícula
  matriculas: Matricula[];
  matricularAsignatura: (grupoId: string) => { exito: boolean; mensaje: string };
  cancelarMatricula: (matriculaId: string) => { exito: boolean; mensaje: string };

  // Calificaciones
  calificaciones: Calificacion[];
  guardarCalificacion: (
    estudianteId: string,
    grupoId: string,
    corte1?: number,
    corte2?: number,
    corte3?: number,
    observaciones?: string
  ) => void;

  // Auditoría
  auditoria: RegistroAuditoria[];
  registrarAuditoria: (
    modulo: RegistroAuditoria['modulo'],
    accion: string,
    detalle: string
  ) => void;

  // Utilidades
  restablecerDatosPrueba: () => void;
}

// Datos iniciales de prueba (Seed Data)
const USUARIOS_DEMO: Record<RolUsuario, Usuario> = {
  Administrador: {
    id: 'usr-admin-1',
    nombre: 'Marlon Vellaizan (Admin)',
    email: 'admin@sga.edu.co',
    rol: 'Administrador',
    codigoIdentificacion: 'ADM-001',
  },
  Coordinador: {
    id: 'usr-coord-1',
    nombre: 'Ing. Carlos Mendoza (Coordinador)',
    email: 'coordinador@sga.edu.co',
    rol: 'Coordinador',
    codigoIdentificacion: 'CRD-204',
    programaId: 'prog-sis',
  },
  Docente: {
    id: 'usr-doc-1',
    nombre: 'Dra. Elena Ramos (Docente)',
    email: 'docente@sga.edu.co',
    rol: 'Docente',
    codigoIdentificacion: 'DOC-102',
  },
  Estudiante: {
    id: 'usr-est-1',
    nombre: 'Marlon Vellaizan (Estudiante)',
    email: 'marlon.vellaizan@cun.edu.co',
    rol: 'Estudiante',
    codigoIdentificacion: 'EST-2024-998',
    programaId: 'prog-sis',
  },
};

const PROGRAMAS_INICIALES: Programa[] = [
  { id: 'prog-sis', codigo: 'ING-SIS', nombre: 'Ingeniería de Sistemas', facultad: 'Facultad de Ingeniería', activo: true },
  { id: 'prog-adm', codigo: 'ADM-EMP', nombre: 'Administración de Empresas', facultad: 'Ciencias Económicas', activo: true },
  { id: 'prog-con', codigo: 'CON-PUB', nombre: 'Contaduría Pública', facultad: 'Ciencias Económicas', activo: true },
];

const DOCENTES_INICIALES: DocenteData[] = [
  { id: 'doc-1', usuarioId: 'usr-doc-1', nombre: 'Dra. Elena Ramos (Docente)', email: 'docente@sga.edu.co', especialidad: 'Arquitectura de Software y Cloud Computing', activo: true },
  { id: 'doc-2', usuarioId: 'usr-doc-2', nombre: 'Mg. Roberto Gómez', email: 'roberto.gomez@sga.edu.co', especialidad: 'Bases de Datos y Big Data', activo: true },
  { id: 'doc-3', usuarioId: 'usr-doc-3', nombre: 'Ing. Patricia Silva', email: 'patricia.silva@sga.edu.co', especialidad: 'Algoritmos y Estructuras de Datos', activo: true },
];

const ESTUDIANTES_INICIALES: EstudianteData[] = [
  { id: 'est-1', usuarioId: 'usr-est-1', nombre: 'Marlon Vellaizan (Estudiante)', email: 'marlon.vellaizan@cun.edu.co', codigoEstudiante: 'EST-2024-998', programaId: 'prog-sis', semestreActual: 6, activo: true },
  { id: 'est-2', usuarioId: 'usr-est-2', nombre: 'Laura Valentina Pérez', email: 'laura.perez@sga.edu.co', codigoEstudiante: 'EST-2024-501', programaId: 'prog-sis', semestreActual: 6, activo: true },
  { id: 'est-3', usuarioId: 'usr-est-3', nombre: 'Juan David Ramírez', email: 'juan.ramirez@sga.edu.co', codigoEstudiante: 'EST-2024-742', programaId: 'prog-sis', semestreActual: 6, activo: true },
  { id: 'est-4', usuarioId: 'usr-est-4', nombre: 'Camila Andrea Torres', email: 'camila.torres@sga.edu.co', codigoEstudiante: 'EST-2024-811', programaId: 'prog-sis', semestreActual: 5, activo: true },
];

const ASIGNATURAS_INICIALES: Asignatura[] = [
  { id: 'asig-1', codigo: 'SIS-601', nombre: 'Arquitectura de Software', creditos: 3, programaId: 'prog-sis', periodo: '2026-1', activo: true },
  { id: 'asig-2', codigo: 'SIS-602', nombre: 'Bases de Datos Avanzadas', creditos: 4, programaId: 'prog-sis', periodo: '2026-1', activo: true },
  { id: 'asig-3', codigo: 'SIS-603', nombre: 'Redes y Comunicaciones', creditos: 3, programaId: 'prog-sis', periodo: '2026-1', activo: true },
  { id: 'asig-4', codigo: 'SIS-604', nombre: 'Ingeniería de Requisitos', creditos: 3, programaId: 'prog-sis', periodo: '2026-1', activo: true },
  { id: 'asig-5', codigo: 'ADM-101', nombre: 'Teoría de las Organizaciones', creditos: 3, programaId: 'prog-adm', periodo: '2026-1', activo: true },
];

const GRUPOS_INICIALES: Grupo[] = [
  { id: 'grp-1', asignaturaId: 'asig-1', numeroGrupo: '01D', docenteId: 'doc-1', horario: 'Lunes y Miércoles 08:00 - 10:00', aula: 'Laboratorio de Software 3', cupoMaximo: 25, cupoDisponible: 23, periodo: '2026-1', activo: true },
  { id: 'grp-2', asignaturaId: 'asig-1', numeroGrupo: '02N', docenteId: 'doc-1', horario: 'Martes y Jueves 18:30 - 20:30', aula: 'Aula Virtual Teams A', cupoMaximo: 30, cupoDisponible: 29, periodo: '2026-1', activo: true },
  { id: 'grp-3', asignaturaId: 'asig-2', numeroGrupo: '01D', docenteId: 'doc-2', horario: 'Martes y Jueves 10:00 - 12:00', aula: 'Laboratorio de BD 2', cupoMaximo: 20, cupoDisponible: 18, periodo: '2026-1', activo: true },
  { id: 'grp-4', asignaturaId: 'asig-3', numeroGrupo: '01D', docenteId: 'doc-3', horario: 'Viernes 08:00 - 12:00', aula: 'Laboratorio Redes Cisco', cupoMaximo: 25, cupoDisponible: 24, periodo: '2026-1', activo: true },
  { id: 'grp-5', asignaturaId: 'asig-4', numeroGrupo: '01N', docenteId: 'doc-1', horario: 'Sábados 08:00 - 12:00', aula: 'Aula 402', cupoMaximo: 1, cupoDisponible: 0, periodo: '2026-1', activo: true }, // Cupo lleno para probar validación
];

const MATRICULAS_INICIALES: Matricula[] = [
  { id: 'mat-1', estudianteId: 'est-1', grupoId: 'grp-1', asignaturaId: 'asig-1', periodo: '2026-1', fechaMatricula: '2026-02-10 09:30', estado: 'Activa' },
  { id: 'mat-2', estudianteId: 'est-2', grupoId: 'grp-1', asignaturaId: 'asig-1', periodo: '2026-1', fechaMatricula: '2026-02-10 10:15', estado: 'Activa' },
  { id: 'mat-3', estudianteId: 'est-3', grupoId: 'grp-3', asignaturaId: 'asig-2', periodo: '2026-1', fechaMatricula: '2026-02-11 14:00', estado: 'Activa' },
  { id: 'mat-4', estudianteId: 'est-1', grupoId: 'grp-3', asignaturaId: 'asig-2', periodo: '2026-1', fechaMatricula: '2026-02-11 15:30', estado: 'Activa' },
  { id: 'mat-5', estudianteId: 'est-4', grupoId: 'grp-5', asignaturaId: 'asig-4', periodo: '2026-1', fechaMatricula: '2026-02-12 11:20', estado: 'Activa' },
];

const CALIFICACIONES_INICIALES: Calificacion[] = [
  {
    id: 'cal-1',
    matriculaId: 'mat-1',
    estudianteId: 'est-1',
    grupoId: 'grp-1',
    asignaturaId: 'asig-1',
    corte1: 4.5,
    corte2: 4.8,
    corte3: 4.2,
    definitiva: 4.47,
    observaciones: 'Excelente sustentación del proyecto de monolito modular.',
    fechaActualizacion: '2026-04-15 14:20',
    actualizadoPor: 'Dra. Elena Ramos (Docente)',
  },
  {
    id: 'cal-2',
    matriculaId: 'mat-2',
    estudianteId: 'est-2',
    grupoId: 'grp-1',
    asignaturaId: 'asig-1',
    corte1: 3.8,
    corte2: 4.0,
    corte3: 3.5,
    definitiva: 3.74,
    observaciones: 'Buen desempeño general.',
    fechaActualizacion: '2026-04-15 14:25',
    actualizadoPor: 'Dra. Elena Ramos (Docente)',
  },
  {
    id: 'cal-3',
    matriculaId: 'mat-4',
    estudianteId: 'est-1',
    grupoId: 'grp-3',
    asignaturaId: 'asig-2',
    corte1: 4.0,
    corte2: 3.9,
    corte3: 4.3,
    definitiva: 4.09,
    observaciones: 'Consultas SQL indexadas y procedimientos optimizados.',
    fechaActualizacion: '2026-04-18 10:15',
    actualizadoPor: 'Mg. Roberto Gómez',
  },
];

const AUDITORIA_INICIAL: RegistroAuditoria[] = [
  {
    id: 'aud-1',
    fechaHora: '2026-02-01 08:00:12',
    usuarioId: 'usr-admin-1',
    usuarioNombre: 'Marlon Vellaizan (Admin)',
    rol: 'Administrador',
    modulo: 'Gestión Académica',
    accion: 'CREAR_PERIODO',
    detalle: 'Apertura oficial del Período Académico 2026-1 con calendario de matrículas.',
    ip: '192.168.1.5',
  },
  {
    id: 'aud-2',
    fechaHora: '2026-02-05 11:22:45',
    usuarioId: 'usr-coord-1',
    usuarioNombre: 'Ing. Carlos Mendoza (Coordinador)',
    rol: 'Coordinador',
    modulo: 'Gestión Académica',
    accion: 'ASIGNAR_DOCENTE',
    detalle: 'Asignación de Dra. Elena Ramos al curso Arquitectura de Software (Grupo 01D y 02N).',
    ip: '192.168.1.18',
  },
  {
    id: 'aud-3',
    fechaHora: '2026-02-10 09:30:00',
    usuarioId: 'usr-est-1',
    usuarioNombre: 'Marlon Vellaizan (Estudiante)',
    rol: 'Estudiante',
    modulo: 'Matrícula',
    accion: 'MATRICULA_EXITOSA',
    detalle: 'Inscripción de asignatura Arquitectura de Software en Grupo 01D. Cupo descontado.',
    ip: '192.168.1.23',
  },
  {
    id: 'aud-4',
    fechaHora: '2026-04-15 14:20:10',
    usuarioId: 'usr-doc-1',
    usuarioNombre: 'Dra. Elena Ramos (Docente)',
    rol: 'Docente',
    modulo: 'Calificaciones',
    accion: 'REGISTRO_CALIFICACION',
    detalle: 'Asentamiento de notas para Marlon Vellaizan en Arquitectura de Software (Definitiva: 4.47).',
    ip: '192.168.1.44',
  },
];

const SGAContext = createContext<SGAContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY_PREFIX = 'sga_db_';

function getStored<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(LOCAL_STORAGE_KEY_PREFIX + key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error('Error saving to localStorage', e);
  }
}

export const SGAProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Estado de Usuario actual (por defecto inicia con Administrador para explorar de inmediato)
  const [usuarioActual, setUsuarioActual] = useState<Usuario | null>(() =>
    getStored<Usuario | null>('usuario_actual', USUARIOS_DEMO.Administrador)
  );

  // Estados persistentes
  const [programas, setProgramas] = useState<Programa[]>(() =>
    getStored<Programa[]>('programas', PROGRAMAS_INICIALES)
  );
  const [asignaturas, setAsignaturas] = useState<Asignatura[]>(() =>
    getStored<Asignatura[]>('asignaturas', ASIGNATURAS_INICIALES)
  );
  const [docentes, setDocentes] = useState<DocenteData[]>(() =>
    getStored<DocenteData[]>('docentes', DOCENTES_INICIALES)
  );
  const [estudiantes, setEstudiantes] = useState<EstudianteData[]>(() =>
    getStored<EstudianteData[]>('estudiantes', ESTUDIANTES_INICIALES)
  );
  const [grupos, setGrupos] = useState<Grupo[]>(() =>
    getStored<Grupo[]>('grupos', GRUPOS_INICIALES)
  );
  const [matriculas, setMatriculas] = useState<Matricula[]>(() =>
    getStored<Matricula[]>('matriculas', MATRICULAS_INICIALES)
  );
  const [calificaciones, setCalificaciones] = useState<Calificacion[]>(() =>
    getStored<Calificacion[]>('calificaciones', CALIFICACIONES_INICIALES)
  );
  const [auditoria, setAuditoria] = useState<RegistroAuditoria[]>(() =>
    getStored<RegistroAuditoria[]>('auditoria', AUDITORIA_INICIAL)
  );

  // Efectos de persistencia
  useEffect(() => setStored('usuario_actual', usuarioActual), [usuarioActual]);
  useEffect(() => setStored('programas', programas), [programas]);
  useEffect(() => setStored('asignaturas', asignaturas), [asignaturas]);
  useEffect(() => setStored('docentes', docentes), [docentes]);
  useEffect(() => setStored('estudiantes', estudiantes), [estudiantes]);
  useEffect(() => setStored('grupos', grupos), [grupos]);
  useEffect(() => setStored('matriculas', matriculas), [matriculas]);
  useEffect(() => setStored('calificaciones', calificaciones), [calificaciones]);
  useEffect(() => setStored('auditoria', auditoria), [auditoria]);

  // Función interna para registrar en auditoría
  const registrarAuditoria = (
    modulo: RegistroAuditoria['modulo'],
    accion: string,
    detalle: string
  ) => {
    const nuevoLog: RegistroAuditoria = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      fechaHora: new Date().toLocaleString('es-CO', { hour12: false }),
      usuarioId: usuarioActual ? usuarioActual.id : 'sistema-anonimo',
      usuarioNombre: usuarioActual ? usuarioActual.nombre : 'Usuario Anónimo',
      rol: usuarioActual ? usuarioActual.rol : 'Estudiante',
      modulo,
      accion,
      detalle,
      ip: '127.0.0.1 (Local)',
    };
    setAuditoria((prev) => [nuevoLog, ...prev]);
  };

  // Autenticación
  const login = (email: string, rolElegido?: RolUsuario): boolean => {
    // Buscar si coincide con alguno de los usuarios de prueba
    const match = Object.values(USUARIOS_DEMO).find(
      (u) => u.email.toLowerCase() === email.toLowerCase()
    );

    let usuarioSeleccionado: Usuario;
    if (match) {
      usuarioSeleccionado = match;
    } else {
      const rolFinal = rolElegido || 'Estudiante';
      usuarioSeleccionado = {
        id: `usr-${Date.now()}`,
        nombre: email.split('@')[0],
        email,
        rol: rolFinal,
        codigoIdentificacion: `COD-${Math.floor(1000 + Math.random() * 9000)}`,
        programaId: 'prog-sis',
      };
    }

    setUsuarioActual(usuarioSeleccionado);
    registrarAuditoria(
      'Autenticación',
      'INICIO_SESION',
      `Inicio de sesión exitoso con rol ${usuarioSeleccionado.rol} (${usuarioSeleccionado.email}).`
    );
    return true;
  };

  const loginRapido = (rol: RolUsuario) => {
    const usuario = USUARIOS_DEMO[rol];
    setUsuarioActual(usuario);
    registrarAuditoria(
      'Autenticación',
      'INICIO_SESION_SIMULADO',
      `Acceso rápido al perfil de ${rol} (${usuario.nombre}).`
    );
  };

  const logout = () => {
    if (usuarioActual) {
      registrarAuditoria(
        'Autenticación',
        'CIERRE_SESION',
        `Cierre de sesión de ${usuarioActual.nombre}.`
      );
    }
    setUsuarioActual(null);
  };

  // CRUD Programas
  const crearPrograma = (datos: Omit<Programa, 'id'>) => {
    const nuevo: Programa = {
      ...datos,
      id: `prog-${Date.now()}`,
    };
    setProgramas((prev) => [...prev, nuevo]);
    registrarAuditoria(
      'Gestión Académica',
      'CREAR_PROGRAMA',
      `Programa creado: ${nuevo.nombre} (${nuevo.codigo}).`
    );
  };

  const editarPrograma = (p: Programa) => {
    setProgramas((prev) => prev.map((item) => (item.id === p.id ? p : item)));
    registrarAuditoria(
      'Gestión Académica',
      'EDITAR_PROGRAMA',
      `Programa actualizado: ${p.nombre}.`
    );
  };

  const toggleProgramaActivo = (id: string) => {
    setProgramas((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nuevoEstado = !item.activo;
          registrarAuditoria(
            'Gestión Académica',
            nuevoEstado ? 'ACTIVAR_PROGRAMA' : 'DESACTIVAR_PROGRAMA',
            `Estado del programa ${item.nombre} cambiado a ${nuevoEstado ? 'Activo' : 'Inactivo'}.`
          );
          return { ...item, activo: nuevoEstado };
        }
        return item;
      })
    );
  };

  // CRUD Asignaturas
  const crearAsignatura = (datos: Omit<Asignatura, 'id'>) => {
    const nuevo: Asignatura = {
      ...datos,
      id: `asig-${Date.now()}`,
    };
    setAsignaturas((prev) => [...prev, nuevo]);
    registrarAuditoria(
      'Gestión Académica',
      'CREAR_ASIGNATURA',
      `Asignatura creada: ${nuevo.nombre} (${nuevo.codigo}, ${nuevo.creditos} créditos).`
    );
  };

  const editarAsignatura = (a: Asignatura) => {
    setAsignaturas((prev) => prev.map((item) => (item.id === a.id ? a : item)));
    registrarAuditoria(
      'Gestión Académica',
      'EDITAR_ASIGNATURA',
      `Asignatura actualizada: ${a.nombre}.`
    );
  };

  const toggleAsignaturaActiva = (id: string) => {
    setAsignaturas((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nuevoEstado = !item.activo;
          registrarAuditoria(
            'Gestión Académica',
            nuevoEstado ? 'ACTIVAR_ASIGNATURA' : 'DESACTIVAR_ASIGNATURA',
            `Asignatura ${item.nombre} cambiada a ${nuevoEstado ? 'Activa' : 'Inactiva'}.`
          );
          return { ...item, activo: nuevoEstado };
        }
        return item;
      })
    );
  };

  // CRUD Docentes
  const crearDocente = (datos: Omit<DocenteData, 'id' | 'usuarioId'>) => {
    const docId = `doc-${Date.now()}`;
    const usrId = `usr-doc-${Date.now()}`;
    const nuevo: DocenteData = {
      ...datos,
      id: docId,
      usuarioId: usrId,
    };
    setDocentes((prev) => [...prev, nuevo]);
    registrarAuditoria(
      'Gestión Académica',
      'CREAR_DOCENTE',
      `Nuevo docente vinculado: ${nuevo.nombre} (${nuevo.especialidad}).`
    );
  };

  const editarDocente = (d: DocenteData) => {
    setDocentes((prev) => prev.map((item) => (item.id === d.id ? d : item)));
    registrarAuditoria(
      'Gestión Académica',
      'EDITAR_DOCENTE',
      `Docente modificado: ${d.nombre}.`
    );
  };

  const toggleDocenteActivo = (id: string) => {
    setDocentes((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nuevoEstado = !item.activo;
          registrarAuditoria(
            'Gestión Académica',
            nuevoEstado ? 'ACTIVAR_DOCENTE' : 'DESACTIVAR_DOCENTE',
            `Docente ${item.nombre} marcado como ${nuevoEstado ? 'Activo' : 'Inactivo'}.`
          );
          return { ...item, activo: nuevoEstado };
        }
        return item;
      })
    );
  };

  // CRUD Estudiantes
  const crearEstudiante = (datos: Omit<EstudianteData, 'id' | 'usuarioId'>) => {
    const estId = `est-${Date.now()}`;
    const usrId = `usr-est-${Date.now()}`;
    const nuevo: EstudianteData = {
      ...datos,
      id: estId,
      usuarioId: usrId,
    };
    setEstudiantes((prev) => [...prev, nuevo]);
    registrarAuditoria(
      'Gestión Académica',
      'CREAR_ESTUDIANTE',
      `Estudiante registrado: ${nuevo.nombre} (Código: ${nuevo.codigoEstudiante}).`
    );
  };

  const editarEstudiante = (e: EstudianteData) => {
    setEstudiantes((prev) => prev.map((item) => (item.id === e.id ? e : item)));
    registrarAuditoria(
      'Gestión Académica',
      'EDITAR_ESTUDIANTE',
      `Estudiante actualizado: ${e.nombre}.`
    );
  };

  const toggleEstudianteActivo = (id: string) => {
    setEstudiantes((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nuevoEstado = !item.activo;
          registrarAuditoria(
            'Gestión Académica',
            nuevoEstado ? 'ACTIVAR_ESTUDIANTE' : 'DESACTIVAR_ESTUDIANTE',
            `Estudiante ${item.nombre} marcado como ${nuevoEstado ? 'Activo' : 'Inactivo'}.`
          );
          return { ...item, activo: nuevoEstado };
        }
        return item;
      })
    );
  };

  // CRUD Grupos
  const crearGrupo = (datos: Omit<Grupo, 'id' | 'cupoDisponible'>) => {
    const nuevo: Grupo = {
      ...datos,
      id: `grp-${Date.now()}`,
      cupoDisponible: datos.cupoMaximo,
    };
    setGrupos((prev) => [...prev, nuevo]);
    const asig = asignaturas.find((a) => a.id === nuevo.asignaturaId);
    registrarAuditoria(
      'Gestión Académica',
      'CREAR_GRUPO',
      `Apertura de Grupo ${nuevo.numeroGrupo} para la asignatura ${asig ? asig.nombre : nuevo.asignaturaId} (${nuevo.cupoMaximo} cupos).`
    );
  };

  const editarGrupo = (g: Grupo) => {
    setGrupos((prev) => prev.map((item) => (item.id === g.id ? g : item)));
    registrarAuditoria(
      'Gestión Académica',
      'EDITAR_GRUPO',
      `Grupo ${g.numeroGrupo} actualizado.`
    );
  };

  const toggleGrupoActivo = (id: string) => {
    setGrupos((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nuevoEstado = !item.activo;
          registrarAuditoria(
            'Gestión Académica',
            nuevoEstado ? 'ACTIVAR_GRUPO' : 'DESACTIVAR_GRUPO',
            `Grupo ${item.numeroGrupo} marcado como ${nuevoEstado ? 'Activo' : 'Inactivo'}.`
          );
          return { ...item, activo: nuevoEstado };
        }
        return item;
      })
    );
  };

  // Matrícula (Solo Estudiante)
  const matricularAsignatura = (grupoId: string): { exito: boolean; mensaje: string } => {
    if (!usuarioActual) {
      return { exito: false, mensaje: 'Debes iniciar sesión para matricular asignaturas.' };
    }
    if (usuarioActual.rol !== 'Estudiante') {
      return { exito: false, mensaje: 'Solo los estudiantes pueden realizar matrícula de asignaturas.' };
    }

    // Identificar el registro del estudiante correspondiente al usuario
    let estudiante = estudiantes.find((e) => e.usuarioId === usuarioActual.id);
    if (!estudiante) {
      // Si el estudiante inició sesión y no está mapeado aún, mapeamos a 'est-1' por defecto
      estudiante = estudiantes[0];
    }

    const grupo = grupos.find((g) => g.id === grupoId);
    if (!grupo) {
      return { exito: false, mensaje: 'El grupo seleccionado no existe o no está disponible.' };
    }
    if (!grupo.activo) {
      return { exito: false, mensaje: 'Este grupo se encuentra cerrado o inactivo.' };
    }

    // Validación 1: Cupo disponible
    if (grupo.cupoDisponible <= 0) {
      registrarAuditoria(
        'Matrícula',
        'INTENTO_FALLIDO_CUPO_AGOTADO',
        `Estudiante ${estudiante.nombre} intentó matricular en grupo ${grupo.numeroGrupo} sin cupos disponibles.`
      );
      return {
        exito: false,
        mensaje: `No hay cupos disponibles en el Grupo ${grupo.numeroGrupo}. Por favor selecciona otro grupo.`,
      };
    }

    // Validación 2: Que el estudiante no esté ya matriculado en esta misma asignatura (evitar duplicados)
    const yaMatriculadoMateria = matriculas.some(
      (m) =>
        m.estudianteId === estudiante!.id &&
        m.asignaturaId === grupo.asignaturaId &&
        m.estado === 'Activa'
    );

    if (yaMatriculadoMateria) {
      const asig = asignaturas.find((a) => a.id === grupo.asignaturaId);
      registrarAuditoria(
        'Matrícula',
        'INTENTO_FALLIDO_DUPLICADO',
        `Estudiante ${estudiante.nombre} intentó duplicar matrícula en ${asig ? asig.nombre : 'materia'}.`
      );
      return {
        exito: false,
        mensaje: `Ya estás matriculado en la asignatura "${asig ? asig.nombre : 'esta materia'}". No puedes inscribirla dos veces en el mismo período.`,
      };
    }

    // Ejecutar matrícula
    const nuevaMatricula: Matricula = {
      id: `mat-${Date.now()}`,
      estudianteId: estudiante.id,
      grupoId: grupo.id,
      asignaturaId: grupo.asignaturaId,
      periodo: grupo.periodo,
      fechaMatricula: new Date().toLocaleString('es-CO', { hour12: false }),
      estado: 'Activa',
    };

    // Restar cupo atómicamente
    setGrupos((prev) =>
      prev.map((g) =>
        g.id === grupoId ? { ...g, cupoDisponible: Math.max(0, g.cupoDisponible - 1) } : g
      )
    );

    setMatriculas((prev) => [...prev, nuevaMatricula]);

    // Crear registro inicial vacío de calificación para el docente
    const nuevaCal: Calificacion = {
      id: `cal-${Date.now()}`,
      matriculaId: nuevaMatricula.id,
      estudianteId: estudiante.id,
      grupoId: grupo.id,
      asignaturaId: grupo.asignaturaId,
      fechaActualizacion: new Date().toLocaleString('es-CO', { hour12: false }),
      actualizadoPor: 'Sistema (Matrícula inicial)',
    };
    setCalificaciones((prev) => [...prev, nuevaCal]);

    const asig = asignaturas.find((a) => a.id === grupo.asignaturaId);
    registrarAuditoria(
      'Matrícula',
      'MATRICULA_EXITOSA',
      `Estudiante ${estudiante.nombre} matriculó exitosamente "${asig ? asig.nombre : 'materia'}" (Grupo ${grupo.numeroGrupo}, Horario: ${grupo.horario}). Cupo restante: ${grupo.cupoDisponible - 1}.`
    );

    return {
      exito: true,
      mensaje: `¡Matrícula exitosa! Te has inscrito en "${asig ? asig.nombre : 'la asignatura'}" Grupo ${grupo.numeroGrupo}.`,
    };
  };

  const cancelarMatricula = (matriculaId: string): { exito: boolean; mensaje: string } => {
    const mat = matriculas.find((m) => m.id === matriculaId);
    if (!mat) {
      return { exito: false, mensaje: 'Matrícula no encontrada.' };
    }

    // Liberar cupo al grupo
    setGrupos((prev) =>
      prev.map((g) =>
        g.id === mat.grupoId ? { ...g, cupoDisponible: Math.min(g.cupoMaximo, g.cupoDisponible + 1) } : g
      )
    );

    // Cambiar estado a Cancelada
    setMatriculas((prev) =>
      prev.map((m) => (m.id === matriculaId ? { ...m, estado: 'Cancelada' } : m))
    );

    const asig = asignaturas.find((a) => a.id === mat.asignaturaId);
    const est = estudiantes.find((e) => e.id === mat.estudianteId);

    registrarAuditoria(
      'Matrícula',
      'CANCELAR_MATRICULA',
      `Matrícula de ${asig ? asig.nombre : 'materia'} cancelada para ${est ? est.nombre : 'estudiante'}. Cupo liberado.`
    );

    return { exito: true, mensaje: 'Matrícula cancelada y cupo devuelto con éxito.' };
  };

  // Calificaciones
  const guardarCalificacion = (
    estudianteId: string,
    grupoId: string,
    corte1?: number,
    corte2?: number,
    corte3?: number,
    observaciones?: string
  ) => {
    // Cálculo ponderado: Corte 1 (30%), Corte 2 (30%), Corte 3 (40%)
    let definitiva: number | undefined = undefined;
    const n1 = corte1 !== undefined && !isNaN(corte1) ? Number(corte1) : undefined;
    const n2 = corte2 !== undefined && !isNaN(corte2) ? Number(corte2) : undefined;
    const n3 = corte3 !== undefined && !isNaN(corte3) ? Number(corte3) : undefined;

    if (n1 !== undefined && n2 !== undefined && n3 !== undefined) {
      definitiva = Number((n1 * 0.3 + n2 * 0.3 + n3 * 0.4).toFixed(2));
    }

    const grupo = grupos.find((g) => g.id === grupoId);
    const asig = asignaturas.find((a) => a.id === grupo?.asignaturaId);
    const est = estudiantes.find((e) => e.id === estudianteId);

    setCalificaciones((prev) => {
      const existe = prev.find(
        (c) => c.estudianteId === estudianteId && c.grupoId === grupoId
      );

      const fecha = new Date().toLocaleString('es-CO', { hour12: false });
      const autor = usuarioActual?.nombre || 'Docente Titular';

      if (existe) {
        return prev.map((c) =>
          c.id === existe.id
            ? {
                ...c,
                corte1: n1,
                corte2: n2,
                corte3: n3,
                definitiva,
                observaciones: observaciones !== undefined ? observaciones : c.observaciones,
                fechaActualizacion: fecha,
                actualizadoPor: autor,
              }
            : c
        );
      } else {
        const mat = matriculas.find(
          (m) => m.estudianteId === estudianteId && m.grupoId === grupoId
        );
        const nueva: Calificacion = {
          id: `cal-${Date.now()}`,
          matriculaId: mat ? mat.id : `mat-${Date.now()}`,
          estudianteId,
          grupoId,
          asignaturaId: grupo ? grupo.asignaturaId : 'asig-gen',
          corte1: n1,
          corte2: n2,
          corte3: n3,
          definitiva,
          observaciones,
          fechaActualizacion: fecha,
          actualizadoPor: autor,
        };
        return [...prev, nueva];
      }
    });

    registrarAuditoria(
      'Calificaciones',
      'ACTUALIZAR_NOTAS',
      `Calificaciones actualizadas para ${est ? est.nombre : estudianteId} en ${asig ? asig.nombre : 'curso'}. C1: ${n1 ?? '-'}, C2: ${n2 ?? '-'}, C3: ${n3 ?? '-'} (Def: ${definitiva ?? 'En curso'}).`
    );
  };

  const restablecerDatosPrueba = () => {
    localStorage.clear();
    setUsuarioActual(USUARIOS_DEMO.Administrador);
    setProgramas(PROGRAMAS_INICIALES);
    setAsignaturas(ASIGNATURAS_INICIALES);
    setDocentes(DOCENTES_INICIALES);
    setEstudiantes(ESTUDIANTES_INICIALES);
    setGrupos(GRUPOS_INICIALES);
    setMatriculas(MATRICULAS_INICIALES);
    setCalificaciones(CALIFICACIONES_INICIALES);
    setAuditoria(AUDITORIA_INICIAL);
  };

  return (
    <SGAContext.Provider
      value={{
        usuarioActual,
        login,
        loginRapido,
        logout,
        programas,
        crearPrograma,
        editarPrograma,
        toggleProgramaActivo,
        asignaturas,
        crearAsignatura,
        editarAsignatura,
        toggleAsignaturaActiva,
        docentes,
        crearDocente,
        editarDocente,
        toggleDocenteActivo,
        estudiantes,
        crearEstudiante,
        editarEstudiante,
        toggleEstudianteActivo,
        grupos,
        crearGrupo,
        editarGrupo,
        toggleGrupoActivo,
        matriculas,
        matricularAsignatura,
        cancelarMatricula,
        calificaciones,
        guardarCalificacion,
        auditoria,
        registrarAuditoria,
        restablecerDatosPrueba,
      }}
    >
      {children}
    </SGAContext.Provider>
  );
};

export const useSGA = () => {
  const context = useContext(SGAContext);
  if (!context) {
    throw new Error('useSGA debe usarse dentro de un SGAProvider');
  }
  return context;
};
