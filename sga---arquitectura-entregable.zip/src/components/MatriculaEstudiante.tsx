import React, { useState } from 'react';
import { useSGA } from '../context/SGAContext';
import {
  ClipboardList,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  MapPin,
  UserCheck,
  BookOpen,
  Calendar,
  Layers,
  Trash2,
  Sparkles,
} from 'lucide-react';

export const MatriculaEstudiante: React.FC = () => {
  const {
    usuarioActual,
    estudiantes,
    asignaturas,
    grupos,
    docentes,
    programas,
    matriculas,
    matricularAsignatura,
    cancelarMatricula,
  } = useSGA();

  const [notificacion, setNotificacion] = useState<{ tipo: 'exito' | 'error'; mensaje: string } | null>(null);

  // Identificar el estudiante logueado
  const estudiante = estudiantes.find((e) => e.usuarioId === usuarioActual?.id) || estudiantes[0];
  const programaEstudiante = programas.find((p) => p.id === estudiante?.programaId);

  // Obtener matrículas activas del estudiante
  const misMatriculasActivas = matriculas.filter(
    (m) => m.estudianteId === estudiante?.id && m.estado === 'Activa'
  );

  const idsAsignaturasYaMatriculadas = new Set(
    misMatriculasActivas.map((m) => m.asignaturaId)
  );

  // Calcular créditos matriculados
  const totalCreditosMatriculados = misMatriculasActivas.reduce((acc, mat) => {
    const asig = asignaturas.find((a) => a.id === mat.asignaturaId);
    return acc + (asig?.creditos || 0);
  }, 0);

  const handleMatricular = (grupoId: string) => {
    const res = matricularAsignatura(grupoId);
    if (res.exito) {
      setNotificacion({ tipo: 'exito', mensaje: res.mensaje });
    } else {
      setNotificacion({ tipo: 'error', mensaje: res.mensaje });
    }

    setTimeout(() => {
      setNotificacion(null);
    }, 5000);
  };

  const handleCancelar = (matriculaId: string) => {
    const res = cancelarMatricula(matriculaId);
    if (res.exito) {
      setNotificacion({ tipo: 'exito', mensaje: res.mensaje });
    } else {
      setNotificacion({ tipo: 'error', mensaje: res.mensaje });
    }

    setTimeout(() => {
      setNotificacion(null);
    }, 5000);
  };

  // Restringir si no es estudiante
  if (usuarioActual?.rol !== 'Estudiante') {
    return (
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 text-center space-y-4">
        <div className="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center mx-auto">
          <AlertTriangle className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-white">
          Módulo de Matrícula Académica (Portal Estudiante)
        </h3>
        <p className="text-sm text-slate-500 max-w-md mx-auto">
          Actualmente has iniciado sesión como <strong>{usuarioActual?.rol}</strong>. La auto-matrícula de asignaturas está reservada para el rol <strong>Estudiante</strong>.
        </p>
        <p className="text-xs text-indigo-600 font-medium">
          Usa el botón de cambio rápido en la barra superior para cambiar al rol de <strong>Estudiante</strong> y probar el flujo de inscripción.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Student Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md border border-emerald-800/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold border border-emerald-400/30">
              <ClipboardList className="w-3.5 h-3.5" />
              Período de Matrícula Activo: 2026-1
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              Matrícula Académica de Cursos
            </h2>
            <p className="text-xs text-slate-300">
              Estudiante: <strong>{estudiante?.nombre}</strong> (Código: {estudiante?.codigoEstudiante}) • {programaEstudiante?.nombre}
            </p>
          </div>

          <div className="bg-white/10 p-3 rounded-xl border border-white/10 backdrop-blur-xs text-center min-w-[150px]">
            <div className="text-2xl font-black text-emerald-300">
              {totalCreditosMatriculados} / 18
            </div>
            <div className="text-[11px] text-slate-300 font-medium">
              Créditos Inscritos
            </div>
          </div>
        </div>
      </div>

      {/* Notification Banner */}
      {notificacion && (
        <div
          className={`p-4 rounded-xl border flex items-start gap-3 text-xs font-medium animate-fadeIn ${
            notificacion.tipo === 'exito'
              ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/50 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-200'
          }`}
        >
          {notificacion.tipo === 'exito' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          )}
          <div className="space-y-0.5">
            <div className="font-bold text-sm">
              {notificacion.tipo === 'exito' ? '¡Operación Exitosa!' : 'Validación de Matrícula'}
            </div>
            <p className="text-xs leading-relaxed">{notificacion.mensaje}</p>
          </div>
        </div>
      )}

      {/* SECTION 1: MIS ASIGNATURAS MATRICULADAS */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-600" />
            Mis Asignaturas Inscritas ({misMatriculasActivas.length})
          </h3>
          <span className="text-xs text-slate-500 font-mono">
            {totalCreditosMatriculados} créditos registrados
          </span>
        </div>

        {misMatriculasActivas.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {misMatriculasActivas.map((mat) => {
              const asig = asignaturas.find((a) => a.id === mat.asignaturaId);
              const grp = grupos.find((g) => g.id === mat.grupoId);
              const doc = docentes.find((d) => d.id === grp?.docenteId);

              return (
                <div
                  key={mat.id}
                  className="p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/30 dark:bg-emerald-950/20 text-xs space-y-2.5 flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                        {asig?.codigo}
                      </span>
                      <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-100/60 dark:bg-emerald-950/50 px-2 py-0.5 rounded-full">
                        Inscrita
                      </span>
                    </div>

                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      {asig?.nombre}
                    </h4>

                    <div className="space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                      <div>
                        Grupo: <strong>{grp?.numeroGrupo}</strong> ({asig?.creditos} créditos)
                      </div>
                      <div className="flex items-center gap-1.5">
                        <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                        <span>{doc ? doc.nombre : 'Docente por asignar'}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{grp?.horario}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span>{grp?.aula}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-emerald-200/60 dark:border-emerald-900/40 flex items-center justify-between text-[11px]">
                    <span className="text-[10px] text-slate-400 font-mono">
                      {mat.fechaMatricula}
                    </span>
                    <button
                      onClick={() => handleCancelar(mat.id)}
                      className="inline-flex items-center gap-1 text-rose-600 hover:text-rose-700 font-semibold cursor-pointer"
                      title="Cancelar materia y liberar cupo"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Cancelar
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-6 text-xs text-slate-400 space-y-1">
            <p className="font-semibold text-slate-600 dark:text-slate-300">Aún no has matriculado asignaturas este período.</p>
            <p>Selecciona las materias y grupos que desees inscribir en la oferta disponible abajo.</p>
          </div>
        )}
      </div>

      {/* SECTION 2: OFERTA DISPONIBLE PARA MATRÍCULA */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            Oferta Académica Habilitada para Inscripción
          </h3>
          <p className="text-xs text-slate-500">
            Verifica cupos disponibles y horarios. Las materias ya matriculadas se bloquean automáticamente para evitar duplicidad.
          </p>
        </div>

        <div className="space-y-4">
          {asignaturas
            .filter((a) => a.activo)
            .map((asig) => {
              const gruposAsig = grupos.filter((g) => g.asignaturaId === asig.id && g.activo);
              const yaMatriculada = idsAsignaturasYaMatriculadas.has(asig.id);

              return (
                <div
                  key={asig.id}
                  className={`p-4 rounded-xl border text-xs space-y-3 transition-all ${
                    yaMatriculada
                      ? 'bg-slate-50 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800 opacity-80'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-300'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                        {asig.codigo}
                      </span>
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                        {asig.nombre}
                      </h4>
                      <span className="text-[11px] text-slate-400 font-mono">
                        ({asig.creditos} Créditos)
                      </span>
                    </div>

                    {yaMatriculada && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-900">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Ya Inscrita en este período
                      </span>
                    )}
                  </div>

                  {/* Available Groups */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
                    {gruposAsig.map((grp) => {
                      const doc = docentes.find((d) => d.id === grp.docenteId);
                      const sinCupo = grp.cupoDisponible <= 0;
                      const deshabilitado = yaMatriculada || sinCupo;

                      return (
                        <div
                          key={grp.id}
                          className={`p-3 rounded-lg border text-xs flex flex-col justify-between space-y-2 ${
                            sinCupo
                              ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/40'
                              : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/60'
                          }`}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between font-bold">
                              <span className="text-slate-900 dark:text-white">
                                Grupo {grp.numeroGrupo}
                              </span>
                              <span
                                className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                                  sinCupo
                                    ? 'bg-rose-100 text-rose-800 border-rose-300'
                                    : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                }`}
                              >
                                {sinCupo ? '0 Cupos (Lleno)' : `${grp.cupoDisponible} de ${grp.cupoMaximo} cupos`}
                              </span>
                            </div>

                            <div className="text-[11px] text-slate-600 dark:text-slate-400 space-y-0.5">
                              <div>Docente: <strong>{doc ? doc.nombre : 'Por asignar'}</strong></div>
                              <div>Horario: {grp.horario}</div>
                              <div>Aula: {grp.aula}</div>
                            </div>
                          </div>

                          <button
                            disabled={deshabilitado}
                            onClick={() => handleMatricular(grp.id)}
                            className={`w-full py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                              deshabilitado
                                ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-300 dark:border-slate-700'
                                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs active:scale-95'
                            }`}
                          >
                            {yaMatriculada
                              ? 'Materia ya inscrita'
                              : sinCupo
                              ? 'Cupo agotado'
                              : 'Inscribir este Grupo'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};
