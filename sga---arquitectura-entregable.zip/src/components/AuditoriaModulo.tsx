import React, { useState, useMemo } from 'react';
import { useSGA } from '../context/SGAContext';
import {
  FileSearch,
  Shield,
  Search,
  Filter,
  Download,
  RotateCcw,
  CheckCircle2,
  Clock,
  User,
  Activity,
} from 'lucide-react';

export const AuditoriaModulo: React.FC = () => {
  const { auditoria, restablecerDatosPrueba } = useSGA();
  const [filtroModulo, setFiltroModulo] = useState<string>('Todos');
  const [filtroRol, setFiltroRol] = useState<string>('Todos');
  const [busqueda, setBusqueda] = useState<string>('');

  const logsFiltrados = useMemo(() => {
    return auditoria.filter((log) => {
      const matchModulo = filtroModulo === 'Todos' || log.modulo === filtroModulo;
      const matchRol = filtroRol === 'Todos' || log.rol === filtroRol;
      const matchSearch =
        busqueda === '' ||
        log.accion.toLowerCase().includes(busqueda.toLowerCase()) ||
        log.detalle.toLowerCase().includes(busqueda.toLowerCase()) ||
        log.usuarioNombre.toLowerCase().includes(busqueda.toLowerCase());

      return matchModulo && matchRol && matchSearch;
    });
  }, [auditoria, filtroModulo, filtroRol, busqueda]);

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(auditoria, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `SGA_Pistas_Auditoria_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const getModuloBadge = (modulo: string) => {
    switch (modulo) {
      case 'Autenticación':
        return 'bg-violet-50 text-violet-700 border-violet-200 dark:bg-violet-950/50 dark:text-violet-300';
      case 'Gestión Académica':
        return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/50 dark:text-blue-300';
      case 'Matrícula':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300';
      case 'Calificaciones':
        return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300';
      case 'Reportes':
        return 'bg-cyan-50 text-cyan-700 border-cyan-200 dark:bg-cyan-950/50 dark:text-cyan-300';
      default:
        return 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-xs font-semibold mb-1">
            <FileSearch className="w-3.5 h-3.5" />
            Módulo de Auditoría y Trazabilidad (WORM)
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Bitácora Inmutable de Operaciones y Seguridad
          </h2>
          <p className="text-xs text-slate-500">
            Registro automático en tiempo real de cada inicio de sesión, inscripción de matrícula, actualización de notas y cambios académicos.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportJSON}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            Exportar JSON
          </button>
          <button
            onClick={() => {
              if (window.confirm('¿Deseas restablecer la base de datos de prueba a su estado original?')) {
                restablecerDatosPrueba();
              }
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 cursor-pointer shadow-xs"
            title="Reiniciar datos iniciales"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Restablecer Demo
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 text-slate-500 font-medium">
            <Filter className="w-3.5 h-3.5" />
            <span>Módulo:</span>
          </div>
          <select
            value={filtroModulo}
            onChange={(e) => setFiltroModulo(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold"
          >
            <option value="Todos">Todos los módulos</option>
            <option value="Autenticación">Autenticación</option>
            <option value="Gestión Académica">Gestión Académica</option>
            <option value="Matrícula">Matrícula</option>
            <option value="Calificaciones">Calificaciones</option>
            <option value="Reportes">Reportes</option>
          </select>

          <div className="flex items-center gap-1 text-slate-500 font-medium ml-2">
            <span>Rol:</span>
          </div>
          <select
            value={filtroRol}
            onChange={(e) => setFiltroRol(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold"
          >
            <option value="Todos">Todos los roles</option>
            <option value="Administrador">Administrador</option>
            <option value="Coordinador">Coordinador</option>
            <option value="Docente">Docente</option>
            <option value="Estudiante">Estudiante</option>
          </select>
        </div>

        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            placeholder="Buscar por usuario, acción o detalle..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder-slate-400"
          />
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700 uppercase tracking-wider text-[11px]">
                <th className="p-3.5 w-36">Fecha / Hora</th>
                <th className="p-3.5">Usuario & Rol</th>
                <th className="p-3.5">Módulo</th>
                <th className="p-3.5 font-mono">Evento / Acción</th>
                <th className="p-3.5">Detalle Operativo</th>
                <th className="p-3.5 font-mono text-center w-28">IP Origen</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {logsFiltrados.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                  <td className="p-3.5 text-slate-500 font-mono text-[11px] whitespace-nowrap">
                    {log.fechaHora}
                  </td>
                  <td className="p-3.5">
                    <div className="font-semibold text-slate-900 dark:text-white">
                      {log.usuarioNombre}
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Rol: {log.rol}
                    </span>
                  </td>
                  <td className="p-3.5">
                    <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] border ${getModuloBadge(log.modulo)}`}>
                      {log.modulo}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono font-bold text-slate-800 dark:text-slate-200 text-[11px]">
                    {log.accion}
                  </td>
                  <td className="p-3.5 text-slate-700 dark:text-slate-300 leading-relaxed font-sans text-xs">
                    {log.detalle}
                  </td>
                  <td className="p-3.5 text-center font-mono text-[10px] text-slate-400">
                    {log.ip || '127.0.0.1'}
                  </td>
                </tr>
              ))}

              {logsFiltrados.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400 text-xs">
                    No hay registros de auditoría que coincidan con los filtros aplicados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
