import React, { useState } from 'react';
import { useSGA } from '../context/SGAContext';
import {
  GraduationCap,
  Users,
  BookOpen,
  Layers,
  Plus,
  Edit2,
  Power,
  Search,
  CheckCircle2,
  XCircle,
  Building,
  UserCheck,
  Calendar,
  Clock,
  MapPin,
} from 'lucide-react';
import { Programa, Asignatura, DocenteData, EstudianteData, Grupo } from '../types/sga';

export const GestionAcademica: React.FC = () => {
  const {
    usuarioActual,
    programas,
    crearPrograma,
    editarPrograma,
    toggleProgramaActivo,
    asignaturas,
    crearAsignatura,
    editarAsignatura,
    toggleAsignaturaActiva,
    docentes,
    crearDocente,
    editarDocente,
    toggleDocenteActivo,
    estudiantes,
    crearEstudiante,
    editarEstudiante,
    toggleEstudianteActivo,
    grupos,
    crearGrupo,
    editarGrupo,
    toggleGrupoActivo,
  } = useSGA();

  const [activeSubTab, setActiveSubTab] = useState<'estudiantes' | 'docentes' | 'programas' | 'asignaturas'>('estudiantes');
  const [searchTerm, setSearchTerm] = useState('');

  // Modals state
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'crear' | 'editar'>('crear');

  // Form states
  const [editingItem, setEditingItem] = useState<any>(null);

  // Forms data
  const [formDataEstudiante, setFormDataEstudiante] = useState({
    nombre: '',
    email: '',
    codigoEstudiante: '',
    programaId: 'prog-sis',
    semestreActual: 1,
    activo: true,
  });

  const [formDataDocente, setFormDataDocente] = useState({
    nombre: '',
    email: '',
    especialidad: '',
    activo: true,
  });

  const [formDataPrograma, setFormDataPrograma] = useState({
    codigo: '',
    nombre: '',
    facultad: 'Facultad de Ingeniería',
    activo: true,
  });

  const [formDataAsignatura, setFormDataAsignatura] = useState({
    codigo: '',
    nombre: '',
    creditos: 3,
    programaId: 'prog-sis',
    periodo: '2026-1',
    activo: true,
  });

  const [formDataGrupo, setFormDataGrupo] = useState({
    asignaturaId: '',
    numeroGrupo: '01D',
    docenteId: '',
    horario: 'Lunes 08:00 - 12:00',
    aula: 'Laboratorio 1',
    cupoMaximo: 25,
    periodo: '2026-1',
    activo: true,
  });

  const [grupoModalOpen, setGrupoModalOpen] = useState(false);

  // Check RBAC permissions: Only Admin or Coordinador
  const esAutorizado = usuarioActual?.rol === 'Administrador' || usuarioActual?.rol === 'Coordinador';

  if (!esAutorizado) {
    return (
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 text-center space-y-3">
        <XCircle className="w-12 h-12 text-rose-500 mx-auto" />
        <h3 className="text-lg font-bold text-slate-900 dark:text-white">Acceso Restringido</h3>
        <p className="text-sm text-slate-500 max-w-md mx-auto">
          El módulo de <strong>Gestión Académica</strong> requiere permisos de <strong>Administrador</strong> o <strong>Coordinador Académico</strong> (RBAC). Inicia sesión con el rol correspondiente.
        </p>
      </div>
    );
  }

  const handleOpenCrear = () => {
    setModalMode('crear');
    setEditingItem(null);
    if (activeSubTab === 'estudiantes') {
      setFormDataEstudiante({
        nombre: '',
        email: '',
        codigoEstudiante: `EST-${Date.now().toString().slice(-4)}`,
        programaId: programas[0]?.id || 'prog-sis',
        semestreActual: 1,
        activo: true,
      });
    } else if (activeSubTab === 'docentes') {
      setFormDataDocente({
        nombre: '',
        email: '',
        especialidad: '',
        activo: true,
      });
    } else if (activeSubTab === 'programas') {
      setFormDataPrograma({
        codigo: '',
        nombre: '',
        facultad: 'Facultad de Ingeniería',
        activo: true,
      });
    } else if (activeSubTab === 'asignaturas') {
      setFormDataAsignatura({
        codigo: '',
        nombre: '',
        creditos: 3,
        programaId: programas[0]?.id || 'prog-sis',
        periodo: '2026-1',
        activo: true,
      });
    }
    setModalOpen(true);
  };

  const handleOpenEditar = (item: any) => {
    setModalMode('editar');
    setEditingItem(item);
    if (activeSubTab === 'estudiantes') {
      setFormDataEstudiante({ ...item });
    } else if (activeSubTab === 'docentes') {
      setFormDataDocente({ ...item });
    } else if (activeSubTab === 'programas') {
      setFormDataPrograma({ ...item });
    } else if (activeSubTab === 'asignaturas') {
      setFormDataAsignatura({ ...item });
    }
    setModalOpen(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeSubTab === 'estudiantes') {
      if (modalMode === 'crear') {
        crearEstudiante(formDataEstudiante);
      } else {
        editarEstudiante({ ...formDataEstudiante, id: editingItem.id, usuarioId: editingItem.usuarioId });
      }
    } else if (activeSubTab === 'docentes') {
      if (modalMode === 'crear') {
        crearDocente(formDataDocente);
      } else {
        editarDocente({ ...formDataDocente, id: editingItem.id, usuarioId: editingItem.usuarioId });
      }
    } else if (activeSubTab === 'programas') {
      if (modalMode === 'crear') {
        crearPrograma(formDataPrograma);
      } else {
        editarPrograma({ ...formDataPrograma, id: editingItem.id });
      }
    } else if (activeSubTab === 'asignaturas') {
      if (modalMode === 'crear') {
        crearAsignatura(formDataAsignatura);
      } else {
        editarAsignatura({ ...formDataAsignatura, id: editingItem.id });
      }
    }
    setModalOpen(false);
  };

  const handleOpenCrearGrupo = (asigId: string) => {
    setFormDataGrupo({
      asignaturaId: asigId,
      numeroGrupo: `0${grupos.filter((g) => g.asignaturaId === asigId).length + 1}D`,
      docenteId: docentes[0]?.id || '',
      horario: 'Lunes y Miércoles 08:00 - 10:00',
      aula: 'Laboratorio de Sistemas 1',
      cupoMaximo: 25,
      periodo: '2026-1',
      activo: true,
    });
    setGrupoModalOpen(true);
  };

  const handleSaveGrupo = (e: React.FormEvent) => {
    e.preventDefault();
    crearGrupo(formDataGrupo);
    setGrupoModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 text-xs font-semibold mb-1">
            <GraduationCap className="w-3.5 h-3.5" />
            Módulo de Gestión Académica (CRUD)
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Parametrización y Catálogo Académico
          </h2>
          <p className="text-xs text-slate-500">
            Administración completa de estudiantes, docentes, programas curriculares, asignaturas y oferta de grupos.
          </p>
        </div>

        <button
          onClick={handleOpenCrear}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white transition-all shadow-xs cursor-pointer active:scale-95"
        >
          <Plus className="w-4 h-4" />
          Crear {activeSubTab === 'estudiantes' ? 'Estudiante' : activeSubTab === 'docentes' ? 'Docente' : activeSubTab === 'programas' ? 'Programa' : 'Asignatura'}
        </button>
      </div>

      {/* Navigation Subtabs & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('estudiantes')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeSubTab === 'estudiantes'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Estudiantes ({estudiantes.length})
          </button>
          <button
            onClick={() => setActiveSubTab('docentes')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeSubTab === 'docentes'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            Docentes ({docentes.length})
          </button>
          <button
            onClick={() => setActiveSubTab('programas')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeSubTab === 'programas'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            Programas ({programas.length})
          </button>
          <button
            onClick={() => setActiveSubTab('asignaturas')}
            className={`px-3.5 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeSubTab === 'asignaturas'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Asignaturas & Grupos ({asignaturas.length})
          </button>
        </div>

        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por nombre o código..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* 1. TAB ESTUDIANTES */}
      {activeSubTab === 'estudiantes' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700 uppercase tracking-wider text-[11px]">
                  <th className="p-3.5">Código</th>
                  <th className="p-3.5">Nombre Completo</th>
                  <th className="p-3.5">Correo Electrónico</th>
                  <th className="p-3.5">Programa</th>
                  <th className="p-3.5 text-center">Semestre</th>
                  <th className="p-3.5 text-center">Estado</th>
                  <th className="p-3.5 text-center">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {estudiantes
                  .filter((e) =>
                    e.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    e.codigoEstudiante.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    e.email.toLowerCase().includes(searchTerm.toLowerCase())
                  )
                  .map((est) => {
                    const prog = programas.find((p) => p.id === est.programaId);
                    return (
                      <tr key={est.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                        <td className="p-3.5 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                          {est.codigoEstudiante}
                        </td>
                        <td className="p-3.5 font-semibold text-slate-900 dark:text-white">
                          {est.nombre}
                        </td>
                        <td className="p-3.5 text-slate-600 dark:text-slate-400 font-mono">
                          {est.email}
                        </td>
                        <td className="p-3.5 text-slate-700 dark:text-slate-300">
                          {prog ? prog.nombre : est.programaId}
                        </td>
                        <td className="p-3.5 text-center font-bold text-slate-700 dark:text-slate-300">
                          {est.semestreActual}°
                        </td>
                        <td className="p-3.5 text-center">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              est.activo
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300'
                                : 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300'
                            }`}
                          >
                            {est.activo ? 'Activo' : 'Inactivo'}
                          </span>
                        </td>
                        <td className="p-3.5 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleOpenEditar(est)}
                              className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-indigo-600 transition-colors"
                              title="Editar estudiante"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => toggleEstudianteActivo(est.id)}
                              className={`p-1.5 rounded-md transition-colors ${
                                est.activo
                                  ? 'text-emerald-600 hover:text-rose-600 hover:bg-rose-50'
                                  : 'text-rose-600 hover:text-emerald-600 hover:bg-emerald-50'
                              }`}
                              title={est.activo ? 'Desactivar estudiante' : 'Activar estudiante'}
                            >
                              <Power className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. TAB DOCENTES */}
      {activeSubTab === 'docentes' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700 uppercase tracking-wider text-[11px]">
                  <th className="p-3.5">Docente</th>
                  <th className="p-3.5">Correo Institucional</th>
                  <th className="p-3.5">Especialidad Académica</th>
                  <th className="p-3.5 text-center">Grupos Asignados</th>
                  <th className="p-3.5 text-center">Estado</th>
                  <th className="p-3.5 text-center">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {docentes
                  .filter((d) =>
                    d.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    d.especialidad.toLowerCase().includes(searchTerm.toLowerCase())
                  )
                  .map((doc) => {
                    const gruposDocente = grupos.filter((g) => g.docenteId === doc.id);
                    return (
                      <tr key={doc.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                        <td className="p-3.5 font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                          <UserCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                          <span>{doc.nombre}</span>
                        </td>
                        <td className="p-3.5 text-slate-600 dark:text-slate-400 font-mono">
                          {doc.email}
                        </td>
                        <td className="p-3.5 text-slate-700 dark:text-slate-300">
                          {doc.especialidad}
                        </td>
                        <td className="p-3.5 text-center font-bold text-indigo-600">
                          {gruposDocente.length} grupos
                        </td>
                        <td className="p-3.5 text-center">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              doc.activo
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300'
                                : 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-300'
                            }`}
                          >
                            {doc.activo ? 'Activo' : 'Inactivo'}
                          </span>
                        </td>
                        <td className="p-3.5 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleOpenEditar(doc)}
                              className="p-1.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-indigo-600"
                              title="Editar docente"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => toggleDocenteActivo(doc.id)}
                              className={`p-1.5 rounded-md ${
                                doc.activo ? 'text-emerald-600 hover:text-rose-600' : 'text-rose-600 hover:text-emerald-600'
                              }`}
                              title={doc.activo ? 'Desactivar docente' : 'Activar docente'}
                            >
                              <Power className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. TAB PROGRAMAS */}
      {activeSubTab === 'programas' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {programas
            .filter((p) =>
              p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
              p.codigo.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .map((prog) => {
              const materiasProg = asignaturas.filter((a) => a.programaId === prog.id);
              const estProg = estudiantes.filter((e) => e.programaId === prog.id);
              return (
                <div
                  key={prog.id}
                  className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                        {prog.codigo}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          prog.activo
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}
                      >
                        {prog.activo ? 'Activo' : 'Inactivo'}
                      </span>
                    </div>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white">
                      {prog.nombre}
                    </h3>
                    <p className="text-xs text-slate-500">{prog.facultad}</p>
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
                      <span>{materiasProg.length} Asignaturas</span>
                      <span>{estProg.length} Estudiantes</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={() => handleOpenEditar(prog)}
                      className="px-2.5 py-1 text-xs rounded bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => toggleProgramaActivo(prog.id)}
                      className={`px-2.5 py-1 text-xs rounded font-semibold ${
                        prog.activo
                          ? 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                          : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                      }`}
                    >
                      {prog.activo ? 'Desactivar' : 'Activar'}
                    </button>
                  </div>
                </div>
              );
            })}
        </div>
      )}

      {/* 4. TAB ASIGNATURAS Y GRUPOS */}
      {activeSubTab === 'asignaturas' && (
        <div className="space-y-4">
          {asignaturas
            .filter((a) =>
              a.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
              a.codigo.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .map((asig) => {
              const gruposAsig = grupos.filter((g) => g.asignaturaId === asig.id);
              const prog = programas.find((p) => p.id === asig.programaId);

              return (
                <div
                  key={asig.id}
                  className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs font-bold px-2.5 py-1 rounded bg-indigo-600 text-white">
                        {asig.codigo}
                      </span>
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base flex items-center gap-2">
                          {asig.nombre}
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              asig.activo ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-rose-50 text-rose-700 border-rose-200'
                            }`}
                          >
                            {asig.activo ? 'Activa' : 'Inactiva'}
                          </span>
                        </h4>
                        <div className="text-xs text-slate-400 mt-0.5">
                          {prog ? prog.nombre : asig.programaId} • {asig.creditos} Créditos • Período: {asig.periodo}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleOpenCrearGrupo(asig.id)}
                        className="px-2.5 py-1 rounded-md text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Aperturar Grupo
                      </button>
                      <button
                        onClick={() => handleOpenEditar(asig)}
                        className="p-1 rounded text-slate-400 hover:text-indigo-600"
                        title="Editar asignatura"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => toggleAsignaturaActiva(asig.id)}
                        className={`p-1 rounded ${asig.activo ? 'text-emerald-600 hover:text-rose-600' : 'text-rose-600 hover:text-emerald-600'}`}
                        title={asig.activo ? 'Desactivar asignatura' : 'Activar asignatura'}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* List of groups for this subject */}
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      Grupos Aperturados ({gruposAsig.length})
                    </div>
                    {gruposAsig.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {gruposAsig.map((grp) => {
                          const doc = docentes.find((d) => d.id === grp.docenteId);
                          const cuposOcupados = grp.cupoMaximo - grp.cupoDisponible;
                          const porcentaje = Math.round((cuposOcupados / grp.cupoMaximo) * 100);

                          return (
                            <div
                              key={grp.id}
                              className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-xs space-y-2"
                            >
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-slate-900 dark:text-white">
                                  Grupo {grp.numeroGrupo}
                                </span>
                                <span
                                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                    grp.cupoDisponible === 0
                                      ? 'bg-rose-100 text-rose-800'
                                      : 'bg-emerald-100 text-emerald-800'
                                  }`}
                                >
                                  {grp.cupoDisponible === 0 ? 'Sin Cupo' : `${grp.cupoDisponible} disp.`}
                                </span>
                              </div>

                              <div className="space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                                <div className="flex items-center gap-1.5">
                                  <UserCheck className="w-3 h-3 text-indigo-500" />
                                  <span>{doc ? doc.nombre : 'Sin docente asignado'}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <Clock className="w-3 h-3 text-slate-400" />
                                  <span>{grp.horario}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <MapPin className="w-3 h-3 text-slate-400" />
                                  <span>{grp.aula}</span>
                                </div>
                              </div>

                              {/* Progress bar */}
                              <div className="space-y-1 pt-1">
                                <div className="flex justify-between text-[10px] text-slate-400">
                                  <span>Ocupación: {cuposOcupados}/{grp.cupoMaximo}</span>
                                  <span>{porcentaje}%</span>
                                </div>
                                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                                  <div
                                    className={`h-full ${porcentaje >= 90 ? 'bg-rose-500' : 'bg-indigo-600'}`}
                                    style={{ width: `${porcentaje}%` }}
                                  />
                                </div>
                              </div>

                              <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-200 dark:border-slate-700/50">
                                <button
                                  onClick={() => toggleGrupoActivo(grp.id)}
                                  className="text-[10px] text-slate-500 hover:text-indigo-600 font-semibold"
                                >
                                  {grp.activo ? 'Cerrar Grupo' : 'Reabrir'}
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-xs text-slate-400 italic py-2">
                        No hay grupos aperturados aún para esta asignatura. Haz clic en "Aperturar Grupo".
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
        </div>
      )}

      {/* MODAL: CREAR / EDITAR ENTIDAD */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {modalMode === 'crear' ? 'Crear Nuevo' : 'Editar'}{' '}
              {activeSubTab === 'estudiantes' ? 'Estudiante' : activeSubTab === 'docentes' ? 'Docente' : activeSubTab === 'programas' ? 'Programa' : 'Asignatura'}
            </h3>

            <form onSubmit={handleSubmitForm} className="space-y-3 text-xs">
              {activeSubTab === 'estudiantes' && (
                <>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Nombre Completo</label>
                    <input
                      type="text"
                      required
                      value={formDataEstudiante.nombre}
                      onChange={(e) => setFormDataEstudiante({ ...formDataEstudiante, nombre: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Correo Institucional</label>
                    <input
                      type="email"
                      required
                      value={formDataEstudiante.email}
                      onChange={(e) => setFormDataEstudiante({ ...formDataEstudiante, email: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Código</label>
                      <input
                        type="text"
                        required
                        value={formDataEstudiante.codigoEstudiante}
                        onChange={(e) => setFormDataEstudiante({ ...formDataEstudiante, codigoEstudiante: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Semestre</label>
                      <input
                        type="number"
                        min="1"
                        max="12"
                        required
                        value={formDataEstudiante.semestreActual}
                        onChange={(e) => setFormDataEstudiante({ ...formDataEstudiante, semestreActual: Number(e.target.value) })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Programa</label>
                    <select
                      value={formDataEstudiante.programaId}
                      onChange={(e) => setFormDataEstudiante({ ...formDataEstudiante, programaId: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    >
                      {programas.map((p) => (
                        <option key={p.id} value={p.id}>{p.nombre}</option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              {activeSubTab === 'docentes' && (
                <>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Nombre Completo</label>
                    <input
                      type="text"
                      required
                      value={formDataDocente.nombre}
                      onChange={(e) => setFormDataDocente({ ...formDataDocente, nombre: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Correo Institucional</label>
                    <input
                      type="email"
                      required
                      value={formDataDocente.email}
                      onChange={(e) => setFormDataDocente({ ...formDataDocente, email: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Especialidad Académica</label>
                    <input
                      type="text"
                      required
                      placeholder="Ej. Arquitectura de Software, Redes..."
                      value={formDataDocente.especialidad}
                      onChange={(e) => setFormDataDocente({ ...formDataDocente, especialidad: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                </>
              )}

              {activeSubTab === 'programas' && (
                <>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Código del Programa</label>
                    <input
                      type="text"
                      required
                      placeholder="Ej. ING-SIS"
                      value={formDataPrograma.codigo}
                      onChange={(e) => setFormDataPrograma({ ...formDataPrograma, codigo: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Nombre del Programa</label>
                    <input
                      type="text"
                      required
                      placeholder="Ej. Ingeniería de Sistemas"
                      value={formDataPrograma.nombre}
                      onChange={(e) => setFormDataPrograma({ ...formDataPrograma, nombre: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Facultad</label>
                    <input
                      type="text"
                      required
                      value={formDataPrograma.facultad}
                      onChange={(e) => setFormDataPrograma({ ...formDataPrograma, facultad: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                </>
              )}

              {activeSubTab === 'asignaturas' && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Código</label>
                      <input
                        type="text"
                        required
                        placeholder="Ej. SIS-601"
                        value={formDataAsignatura.codigo}
                        onChange={(e) => setFormDataAsignatura({ ...formDataAsignatura, codigo: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Créditos</label>
                      <input
                        type="number"
                        min="1"
                        max="6"
                        required
                        value={formDataAsignatura.creditos}
                        onChange={(e) => setFormDataAsignatura({ ...formDataAsignatura, creditos: Number(e.target.value) })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Nombre de la Asignatura</label>
                    <input
                      type="text"
                      required
                      placeholder="Ej. Arquitectura de Software"
                      value={formDataAsignatura.nombre}
                      onChange={(e) => setFormDataAsignatura({ ...formDataAsignatura, nombre: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Programa</label>
                    <select
                      value={formDataAsignatura.programaId}
                      onChange={(e) => setFormDataAsignatura({ ...formDataAsignatura, programaId: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    >
                      {programas.map((p) => (
                        <option key={p.id} value={p.id}>{p.nombre}</option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold"
                >
                  {modalMode === 'crear' ? 'Guardar' : 'Actualizar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: APERTURAR GRUPO */}
      {grupoModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Aperturar Nuevo Grupo de Curso
            </h3>

            <form onSubmit={handleSaveGrupo} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Número de Grupo</label>
                  <input
                    type="text"
                    required
                    placeholder="01D"
                    value={formDataGrupo.numeroGrupo}
                    onChange={(e) => setFormDataGrupo({ ...formDataGrupo, numeroGrupo: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Cupo Máximo</label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    required
                    value={formDataGrupo.cupoMaximo}
                    onChange={(e) => setFormDataGrupo({ ...formDataGrupo, cupoMaximo: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Docente Asignado</label>
                <select
                  value={formDataGrupo.docenteId}
                  onChange={(e) => setFormDataGrupo({ ...formDataGrupo, docenteId: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  required
                >
                  <option value="">Seleccionar docente...</option>
                  {docentes.filter((d) => d.activo).map((d) => (
                    <option key={d.id} value={d.id}>{d.nombre} ({d.especialidad})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Horario</label>
                <input
                  type="text"
                  required
                  placeholder="Lunes y Miércoles 08:00 - 10:00"
                  value={formDataGrupo.horario}
                  onChange={(e) => setFormDataGrupo({ ...formDataGrupo, horario: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Aula / Salón</label>
                <input
                  type="text"
                  required
                  placeholder="Laboratorio 3"
                  value={formDataGrupo.aula}
                  onChange={(e) => setFormDataGrupo({ ...formDataGrupo, aula: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setGrupoModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  Aperturar Grupo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
