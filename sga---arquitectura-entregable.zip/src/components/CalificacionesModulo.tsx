import React, { useState } from 'react';
import { useSGA } from '../context/SGAContext';
import {
  Award,
  CheckCircle2,
  XCircle,
  Save,
  Search,
  BookOpen,
  UserCheck,
  Clock,
  Sparkles,
  AlertCircle,
  GraduationCap,
} from 'lucide-react';

export const CalificacionesModulo: React.FC = () => {
  const {
    usuarioActual,
    docentes,
    estudiantes,
    asignaturas,
    grupos,
    matriculas,
    calificaciones,
    guardarCalificacion,
  } = useSGA();

  // Si es docente, encontrar su registro docente
  const docente = docentes.find((d) => d.usuarioId === usuarioActual?.id) || docentes[0];

  // Grupos asignados al docente
  const gruposDocente = grupos.filter((g) => g.docenteId === docente?.id);

  // Estado para grupo seleccionado por el docente
  const [grupoSeleccionadoId, setGrupoSeleccionadoId] = useState<string>(
    gruposDocente[0]?.id || grupos[0]?.id || ''
  );

  // Estado temporal de edición de notas para el grupo seleccionado
  // Map: estudianteId -> { corte1, corte2, corte3, observaciones }
  const [notasTemp, setNotasTemp] = useState<Record<string, { c1: string; c2: string; c3: string; obs: string }>>({});
  const [mensajeGuardado, setMensajeGuardado] = useState<string | null>(null);

  // Estudiante logueado
  const estudianteActual = estudiantes.find((e) => e.usuarioId === usuarioActual?.id) || estudiantes[0];

  // Matrículas del estudiante
  const misMatriculas = matriculas.filter(
    (m) => m.estudianteId === estudianteActual?.id && m.estado === 'Activa'
  );

  // Cálculos para el docente
  const grupoActivo = grupos.find((g) => g.id === grupoSeleccionadoId);
  const asignaturaActiva = asignaturas.find((a) => a.id === grupoActivo?.asignaturaId);

  // Estudiantes inscritos en el grupo activo
  const matriculasEnGrupo = matriculas.filter(
    (m) => m.grupoId === grupoSeleccionadoId && m.estado === 'Activa'
  );

  const handleNotaChange = (estudianteId: string, corte: 'c1' | 'c2' | 'c3', valor: string) => {
    // Validar escala 0.0 a 5.0
    const num = parseFloat(valor);
    if (valor !== '' && (isNaN(num) || num < 0 || num > 5)) {
      return;
    }

    setNotasTemp((prev) => ({
      ...prev,
      [estudianteId]: {
        ...(prev[estudianteId] || { c1: '', c2: '', c3: '', obs: '' }),
        [corte]: valor,
      },
    }));
  };

  const handleObsChange = (estudianteId: string, obs: string) => {
    setNotasTemp((prev) => ({
      ...prev,
      [estudianteId]: {
        ...(prev[estudianteId] || { c1: '', c2: '', c3: '', obs: '' }),
        obs,
      },
    }));
  };

  const handleGuardarNotasEstudiante = (estudianteId: string) => {
    const calExistente = calificaciones.find(
      (c) => c.estudianteId === estudianteId && c.grupoId === grupoSeleccionadoId
    );

    const inputs = notasTemp[estudianteId];
    const c1 = inputs?.c1 !== undefined && inputs.c1 !== '' ? parseFloat(inputs.c1) : calExistente?.corte1;
    const c2 = inputs?.c2 !== undefined && inputs.c2 !== '' ? parseFloat(inputs.c2) : calExistente?.corte2;
    const c3 = inputs?.c3 !== undefined && inputs.c3 !== '' ? parseFloat(inputs.c3) : calExistente?.corte3;
    const obs = inputs?.obs !== undefined ? inputs.obs : calExistente?.observaciones;

    guardarCalificacion(estudianteId, grupoSeleccionadoId, c1, c2, c3, obs);

    setMensajeGuardado(`Calificaciones guardadas exitosamente para el estudiante.`);
    setTimeout(() => setMensajeGuardado(null), 3500);
  };

  // VISTA ESTUDIANTE (Solo ve sus propias notas)
  if (usuarioActual?.rol === 'Estudiante') {
    // Calcular promedio acumulado
    const notasConDefinitiva = misMatriculas
      .map((m) => calificaciones.find((c) => c.estudianteId === estudianteActual.id && c.grupoId === m.grupoId))
      .filter((c) => c?.definitiva !== undefined);

    const sumaDefinitivas = notasConDefinitiva.reduce((acc, c) => acc + (c?.definitiva || 0), 0);
    const promedioSemestre = notasConDefinitiva.length > 0
      ? (sumaDefinitivas / notasConDefinitiva.length).toFixed(2)
      : 'En curso';

    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-amber-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md border border-amber-800/40">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold border border-amber-400/30">
                <Award className="w-3.5 h-3.5" />
                Historial de Calificaciones y Récord Académico
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white">
                Mis Calificaciones (Portal Estudiante)
              </h2>
              <p className="text-xs text-slate-300">
                Consulta confidencial de notas por corte evaluativo para <strong>{estudianteActual.nombre}</strong> (Código: {estudianteActual.codigoEstudiante}).
              </p>
            </div>

            <div className="bg-white/10 p-3 rounded-xl border border-white/10 backdrop-blur-xs text-center min-w-[140px]">
              <div className="text-2xl font-black text-amber-300">
                {promedioSemestre}
              </div>
              <div className="text-[11px] text-slate-300 font-medium">
                Promedio Semestral
              </div>
            </div>
          </div>
        </div>

        {/* Grades Table */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              Asignaturas Cursadas ({misMatriculas.length})
            </h3>
            <span className="text-xs text-slate-500 font-mono">
              Escala Oficial: 0.0 a 5.0 (Aprueba con 3.0)
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700 uppercase tracking-wider text-[11px]">
                  <th className="p-3.5">Asignatura / Grupo</th>
                  <th className="p-3.5">Docente</th>
                  <th className="p-3.5 text-center">Corte 1 (30%)</th>
                  <th className="p-3.5 text-center">Corte 2 (30%)</th>
                  <th className="p-3.5 text-center">Corte 3 (40%)</th>
                  <th className="p-3.5 text-center">Definitiva</th>
                  <th className="p-3.5 text-center">Estado</th>
                  <th className="p-3.5">Observaciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {misMatriculas.map((mat) => {
                  const asig = asignaturas.find((a) => a.id === mat.asignaturaId);
                  const grp = grupos.find((g) => g.id === mat.grupoId);
                  const doc = docentes.find((d) => d.id === grp?.docenteId);
                  const cal = calificaciones.find(
                    (c) => c.estudianteId === estudianteActual.id && c.grupoId === mat.grupoId
                  );

                  const definitiva = cal?.definitiva;
                  const aprobado = definitiva !== undefined && definitiva >= 3.0;

                  return (
                    <tr key={mat.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900 dark:text-white text-sm">
                          {asig?.nombre}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {asig?.codigo} • Grupo {grp?.numeroGrupo} ({asig?.creditos} créditos)
                        </div>
                      </td>
                      <td className="p-3.5 text-slate-700 dark:text-slate-300">
                        {doc ? doc.nombre : 'Docente asignado'}
                      </td>
                      <td className="p-3.5 text-center font-mono font-bold text-slate-800 dark:text-slate-200">
                        {cal?.corte1 !== undefined ? cal.corte1.toFixed(1) : <span className="text-slate-400">—</span>}
                      </td>
                      <td className="p-3.5 text-center font-mono font-bold text-slate-800 dark:text-slate-200">
                        {cal?.corte2 !== undefined ? cal.corte2.toFixed(1) : <span className="text-slate-400">—</span>}
                      </td>
                      <td className="p-3.5 text-center font-mono font-bold text-slate-800 dark:text-slate-200">
                        {cal?.corte3 !== undefined ? cal.corte3.toFixed(1) : <span className="text-slate-400">—</span>}
                      </td>
                      <td className="p-3.5 text-center font-mono text-sm font-black">
                        {definitiva !== undefined ? (
                          <span className={aprobado ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}>
                            {definitiva.toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-xs font-normal">Pendiente</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {definitiva !== undefined ? (
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                              aprobado
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300'
                                : 'bg-rose-50 text-rose-700 border-rose-300 dark:bg-rose-950/60 dark:text-rose-300'
                            }`}
                          >
                            {aprobado ? 'Aprobada' : 'Reprobada'}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                            En curso
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-slate-600 dark:text-slate-400 text-[11px] italic max-w-xs">
                        {cal?.observaciones || 'Sin comentarios registrados por el docente.'}
                      </td>
                    </tr>
                  );
                })}

                {misMatriculas.length === 0 && (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400 text-xs">
                      No tienes asignaturas matriculadas actualmente. Ve a la pestaña "Matrícula" para inscribir materias.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // VISTA DOCENTE (Y ADMIN / COORDINADOR)
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 text-xs font-semibold mb-1">
            <Award className="w-3.5 h-3.5" />
            Módulo de Calificaciones (Planilla Docente)
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Asentamiento y Publicación de Notas
          </h2>
          <p className="text-xs text-slate-500">
            Digita o modifica las notas de los estudiantes matriculados en tus cursos asignados.
          </p>
        </div>

        {/* Group Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-bold text-slate-600 dark:text-slate-300">Seleccionar Curso:</label>
          <select
            value={grupoSeleccionadoId}
            onChange={(e) => {
              setGrupoSeleccionadoId(e.target.value);
              setNotasTemp({});
            }}
            className="text-xs px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold text-slate-900 dark:text-white cursor-pointer"
          >
            {grupos.map((g) => {
              const a = asignaturas.find((as) => as.id === g.asignaturaId);
              return (
                <option key={g.id} value={g.id}>
                  {a ? a.nombre : 'Curso'} — Grupo {g.numeroGrupo} ({g.horario})
                </option>
              );
            })}
          </select>
        </div>
      </div>

      {mensajeGuardado && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 rounded-xl text-xs font-semibold text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{mensajeGuardado}</span>
        </div>
      )}

      {/* Course Info Card */}
      {grupoActivo && asignaturaActiva && (
        <div className="bg-slate-100 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div>
            <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-indigo-600 text-white mr-2">
              {asignaturaActiva.codigo}
            </span>
            <strong className="text-sm font-bold text-slate-900 dark:text-white">
              {asignaturaActiva.nombre}
            </strong>{' '}
            — Grupo {grupoActivo.numeroGrupo}
            <div className="text-slate-500 mt-1">
              Horario: {grupoActivo.horario} • Aula: {grupoActivo.aula} • Período: {grupoActivo.periodo}
            </div>
          </div>
          <div className="flex items-center gap-3 font-mono">
            <span className="px-2.5 py-1 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-bold">
              {matriculasEnGrupo.length} Estudiantes Matriculados
            </span>
          </div>
        </div>
      )}

      {/* Roster Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700 uppercase tracking-wider text-[11px]">
                <th className="p-3.5">Código</th>
                <th className="p-3.5">Estudiante</th>
                <th className="p-3.5 text-center w-28">Corte 1 (30%)</th>
                <th className="p-3.5 text-center w-28">Corte 2 (30%)</th>
                <th className="p-3.5 text-center w-28">Corte 3 (40%)</th>
                <th className="p-3.5 text-center w-24">Definitiva</th>
                <th className="p-3.5 text-center w-28">Estado</th>
                <th className="p-3.5 min-w-[200px]">Observaciones</th>
                <th className="p-3.5 text-center w-24">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {matriculasEnGrupo.map((mat) => {
                const est = estudiantes.find((e) => e.id === mat.estudianteId);
                const cal = calificaciones.find(
                  (c) => c.estudianteId === mat.estudianteId && c.grupoId === grupoSeleccionadoId
                );

                const currentTemp = notasTemp[mat.estudianteId] || {
                  c1: cal?.corte1 !== undefined ? cal.corte1.toString() : '',
                  c2: cal?.corte2 !== undefined ? cal.corte2.toString() : '',
                  c3: cal?.corte3 !== undefined ? cal.corte3.toString() : '',
                  obs: cal?.observaciones || '',
                };

                // Cálculo predictivo en tiempo real
                const n1 = parseFloat(currentTemp.c1);
                const n2 = parseFloat(currentTemp.c2);
                const n3 = parseFloat(currentTemp.c3);
                let defVisual = cal?.definitiva;
                if (!isNaN(n1) && !isNaN(n2) && !isNaN(n3)) {
                  defVisual = Number((n1 * 0.3 + n2 * 0.3 + n3 * 0.4).toFixed(2));
                }

                const aprobado = defVisual !== undefined && defVisual >= 3.0;

                return (
                  <tr key={mat.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono font-bold text-indigo-600">
                      {est?.codigoEstudiante}
                    </td>
                    <td className="p-3.5 font-semibold text-slate-900 dark:text-white">
                      {est?.nombre}
                    </td>
                    <td className="p-3 text-center">
                      <input
                        type="number"
                        min="0"
                        max="5"
                        step="0.1"
                        placeholder="0.0"
                        value={currentTemp.c1}
                        onChange={(e) => handleNotaChange(mat.estudianteId, 'c1', e.target.value)}
                        className="w-16 px-2 py-1 text-center font-mono font-bold text-xs rounded border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:ring-2 focus:ring-indigo-500"
                      />
                    </td>
                    <td className="p-3 text-center">
                      <input
                        type="number"
                        min="0"
                        max="5"
                        step="0.1"
                        placeholder="0.0"
                        value={currentTemp.c2}
                        onChange={(e) => handleNotaChange(mat.estudianteId, 'c2', e.target.value)}
                        className="w-16 px-2 py-1 text-center font-mono font-bold text-xs rounded border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:ring-2 focus:ring-indigo-500"
                      />
                    </td>
                    <td className="p-3 text-center">
                      <input
                        type="number"
                        min="0"
                        max="5"
                        step="0.1"
                        placeholder="0.0"
                        value={currentTemp.c3}
                        onChange={(e) => handleNotaChange(mat.estudianteId, 'c3', e.target.value)}
                        className="w-16 px-2 py-1 text-center font-mono font-bold text-xs rounded border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 focus:ring-2 focus:ring-indigo-500"
                      />
                    </td>
                    <td className="p-3.5 text-center font-mono font-black text-sm">
                      {defVisual !== undefined ? (
                        <span className={aprobado ? 'text-emerald-600' : 'text-rose-600'}>
                          {defVisual.toFixed(2)}
                        </span>
                      ) : (
                        <span className="text-slate-400 font-normal text-xs">—</span>
                      )}
                    </td>
                    <td className="p-3.5 text-center">
                      {defVisual !== undefined ? (
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            aprobado
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                              : 'bg-rose-50 text-rose-700 border-rose-300'
                          }`}
                        >
                          {aprobado ? 'Aprobado' : 'Reprobado'}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[10px]">Incompleto</span>
                      )}
                    </td>
                    <td className="p-3">
                      <input
                        type="text"
                        placeholder="Observación o retroalimentación..."
                        value={currentTemp.obs}
                        onChange={(e) => handleObsChange(mat.estudianteId, e.target.value)}
                        className="w-full px-2 py-1 text-xs rounded border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                      />
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => handleGuardarNotasEstudiante(mat.estudianteId)}
                        className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1 shadow-xs cursor-pointer active:scale-95"
                        title="Guardar calificaciones de este estudiante"
                      >
                        <Save className="w-3 h-3" />
                        Guardar
                      </button>
                    </td>
                  </tr>
                );
              })}

              {matriculasEnGrupo.length === 0 && (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400 text-xs">
                    No hay estudiantes matriculados en este grupo todavía.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
