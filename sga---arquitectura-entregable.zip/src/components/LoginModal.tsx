import React, { useState } from 'react';
import { useSGA } from '../context/SGAContext';
import { RolUsuario } from '../types/sga';
import { ShieldCheck, UserCheck, GraduationCap, Users, Lock, Mail, ArrowRight, X } from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const { login, loginRapido } = useSGA();
  const [email, setEmail] = useState('');
  const [rolElegido, setRolElegido] = useState<RolUsuario>('Estudiante');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      login(email, rolElegido);
      onClose();
    }
  };

  const handleQuick = (rol: RolUsuario) => {
    loginRapido(rol);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center mx-auto shadow-md shadow-indigo-500/20">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white">
            Iniciar Sesión en el SGA
          </h3>
          <p className="text-xs text-slate-500">
            Selecciona un perfil de prueba rápido o ingresa con correo institucional y rol (Control de Acceso RBAC).
          </p>
        </div>

        {/* Quick simulation buttons */}
        <div className="space-y-2">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 text-center">
            Acceso Rápido por Perfil (1 Clic)
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleQuick('Administrador')}
              className="p-3 rounded-xl border border-indigo-200 dark:border-indigo-900 bg-indigo-50/60 dark:bg-indigo-950/40 hover:bg-indigo-100 transition-all text-left space-y-0.5 cursor-pointer"
            >
              <div className="font-bold text-indigo-700 dark:text-indigo-300 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                Administrador
              </div>
              <div className="text-[10px] text-slate-500">Acceso total a todos los módulos</div>
            </button>

            <button
              onClick={() => handleQuick('Coordinador')}
              className="p-3 rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50/60 dark:bg-emerald-950/40 hover:bg-emerald-100 transition-all text-left space-y-0.5 cursor-pointer"
            >
              <div className="font-bold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4" />
                Coordinador
              </div>
              <div className="text-[10px] text-slate-500">Gestión Académica y Reportes</div>
            </button>

            <button
              onClick={() => handleQuick('Docente')}
              className="p-3 rounded-xl border border-amber-200 dark:border-amber-900 bg-amber-50/60 dark:bg-amber-950/40 hover:bg-amber-100 transition-all text-left space-y-0.5 cursor-pointer"
            >
              <div className="font-bold text-amber-700 dark:text-amber-300 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4" />
                Docente
              </div>
              <div className="text-[10px] text-slate-500">Planilla y Asentamiento de Notas</div>
            </button>

            <button
              onClick={() => handleQuick('Estudiante')}
              className="p-3 rounded-xl border border-sky-200 dark:border-sky-900 bg-sky-50/60 dark:bg-sky-950/40 hover:bg-sky-100 transition-all text-left space-y-0.5 cursor-pointer"
            >
              <div className="font-bold text-sky-700 dark:text-sky-300 flex items-center gap-1.5">
                <Users className="w-4 h-4" />
                Estudiante
              </div>
              <div className="text-[10px] text-slate-500">Matrícula y Consulta de Notas</div>
            </button>
          </div>
        </div>

        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
          <span className="flex-shrink mx-3 text-[11px] text-slate-400 font-semibold uppercase">O ingresa manualmente</span>
          <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
        </div>

        {/* Custom Form */}
        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Correo Electrónico Institucional
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                required
                placeholder="ejemplo@sga.edu.co"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Rol Asignado
            </label>
            <select
              value={rolElegido}
              onChange={(e) => setRolElegido(e.target.value as RolUsuario)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold"
            >
              <option value="Administrador">Administrador</option>
              <option value="Coordinador">Coordinador</option>
              <option value="Docente">Docente</option>
              <option value="Estudiante">Estudiante</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-500/20 cursor-pointer active:scale-95 transition-all"
          >
            Ingresar al Sistema <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
