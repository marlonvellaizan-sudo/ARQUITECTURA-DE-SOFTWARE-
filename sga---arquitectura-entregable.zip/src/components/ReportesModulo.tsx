import React, { useState, useMemo } from 'react';
import { useSGA } from '../context/SGAContext';
import {
  BarChart3,
  TrendingUp,
  Users,
  Award,
  BookOpen,
  PieChart,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Download,
} from 'lucide-react';

export const ReportesModulo: React.FC = () => {
  const {
    usuarioActual,
    programas,
    asignaturas,
    grupos,
    estudiantes,
    matriculas,
    calificaciones,
  } = useSGA();

  const [filtroPeriodo, setFiltroPeriodo] = useState<string>('Todos');
  const [filtroPrograma, setFiltroPrograma] = useState<string>('Todos');

  // Filtrado reactivo de métricas
  const matriculasFiltradas = useMemo(() => {
    return matriculas.filter((m) => {
      if (m.estado !== 'Activa') return false;
      const asig = asignaturas.find((a) => a.id === m.asignaturaId);
      const matchPeriodo = filtroPeriodo === 'Todos' || m.periodo === filtroPeriodo;
      const matchPrograma = filtroPrograma === 'Todos' || asig?.programaId === filtroPrograma;
      return matchPeriodo && matchPrograma;
    });
  }, [matriculas, asignaturas, filtroPeriodo, filtroPrograma]);

  // Calificaciones correspondientes
  const calificacionesFiltradas = useMemo(() => {
    const idsMatriculas = new Set(matriculasFiltradas.map((m) => m.id));
    return calificaciones.filter((c) => idsMatriculas.has(c.matriculaId) && c.definitiva !== undefined);
  }, [calificaciones, matriculasFiltradas]);

  // Indicadores
  const totalInscritos = matriculasFiltradas.length;
  const estudiantesUnicos = new Set(matriculasFiltradas.map((m) => m.estudianteId)).size;

  const totalAprobados = calificacionesFiltradas.filter((c) => (c.definitiva || 0) >= 3.0).length;
  const totalReprobados = calificacionesFiltradas.filter((c) => (c.definitiva || 0) < 3.0).length;
  const totalCalificados = calificacionesFiltradas.length;

  const tasaAprobacion = totalCalificados > 0 ? Math.round((totalAprobados / totalCalificados) * 100) : 100;
  const tasaReprobacion = totalCalificados > 0 ? Math.round((totalReprobados / totalCalificados) * 100) : 0;

  const promedioGeneral = totalCalificados > 0
    ? (calificacionesFiltradas.reduce((acc, c) => acc + (c.definitiva || 0), 0) / totalCalificados).toFixed(2)
    : '4.10';

  // Ocupación de cupos
  const gruposFiltrados = useMemo(() => {
    return grupos.filter((g) => {
      const asig = asignaturas.find((a) => a.id === g.asignaturaId);
      const matchPeriodo = filtroPeriodo === 'Todos' || g.periodo === filtroPeriodo;
      const matchPrograma = filtroPrograma === 'Todos' || asig?.programaId === filtroPrograma;
      return matchPeriodo && matchPrograma;
    });
  }, [grupos, asignaturas, filtroPeriodo, filtroPrograma]);

  const totalCuposOfertados = gruposFiltrados.reduce((acc, g) => acc + g.cupoMaximo, 0);
  const totalCuposDisponibles = gruposFiltrados.reduce((acc, g) => acc + g.cupoDisponible, 0);
  const totalCuposOcupados = totalCuposOfertados - totalCuposDisponibles;
  const porcentajeOcupacion = totalCuposOfertados > 0 ? Math.round((totalCuposOcupados / totalCuposOfertados) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 text-xs font-semibold mb-1">
            <BarChart3 className="w-3.5 h-3.5" />
            Módulo de Reportes & Analítica Académica
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Tablero de Desempeño y Métricas Institucionales
          </h2>
          <p className="text-xs text-slate-500">
            Filtra por período académico o programa curricular para visualizar indicadores clave de rendimiento.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span>Período:</span>
          </div>
          <select
            value={filtroPeriodo}
            onChange={(e) => setFiltroPeriodo(e.target.value)}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold text-slate-800 dark:text-slate-200"
          >
            <option value="Todos">Todos los períodos</option>
            <option value="2026-1">2026-1 (Vigente)</option>
            <option value="2025-2">2025-2 (Histórico)</option>
          </select>

          <div className="flex items-center gap-1 text-xs text-slate-500 ml-2">
            <span>Programa:</span>
          </div>
          <select
            value={filtroPrograma}
            onChange={(e) => setFiltroPrograma(e.target.value)}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold text-slate-800 dark:text-slate-200"
          >
            <option value="Todos">Todos los programas</option>
            {programas.map((p) => (
              <option key={p.id} value={p.id}>{p.nombre}</option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1 */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Total Matrículas</span>
            <Users className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {totalInscritos}
          </div>
          <div className="text-[11px] text-slate-400">
            {estudiantesUnicos} estudiantes activos
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Promedio General</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400">
            {promedioGeneral}
          </div>
          <div className="text-[11px] text-slate-400">
            Escala oficial de 0.0 a 5.0
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Tasa de Aprobación</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
            {tasaAprobacion}%
          </div>
          <div className="text-[11px] text-slate-400">
            {totalAprobados} asignaturas aprobadas
          </div>
        </div>

        {/* Card 4 */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Ocupación de Cupos</span>
            <PieChart className="w-4 h-4 text-cyan-500" />
          </div>
          <div className="text-2xl font-black text-cyan-600 dark:text-cyan-400">
            {porcentajeOcupacion}%
          </div>
          <div className="text-[11px] text-slate-400">
            {totalCuposOcupados} de {totalCuposOfertados} cupos ocupados
          </div>
        </div>
      </div>

      {/* Visual Analytics Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Performance Breakdown */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            Balance de Rendimiento Académico
          </h3>

          <div className="space-y-3 text-xs">
            {/* Aprobados */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold">
                <span className="text-emerald-700 dark:text-emerald-400">Aprobados (Nota &ge; 3.0)</span>
                <span>{tasaAprobacion}% ({totalAprobados})</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${tasaAprobacion}%` }} />
              </div>
            </div>

            {/* Reprobados */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold">
                <span className="text-rose-700 dark:text-rose-400">Reprobados (Nota &lt; 3.0)</span>
                <span>{tasaReprobacion}% ({totalReprobados})</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full rounded-full transition-all duration-500" style={{ width: `${tasaReprobacion}%` }} />
              </div>
            </div>

            {/* Ocupación de cupos */}
            <div className="space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex justify-between font-semibold">
                <span className="text-indigo-700 dark:text-indigo-400">Ocupación de Oferta Académica</span>
                <span>{porcentajeOcupacion}%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-indigo-600 h-full rounded-full transition-all duration-500" style={{ width: `${porcentajeOcupacion}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Subjects summary */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-600" />
            Demanda por Asignatura (Matrículas Registradas)
          </h3>

          <div className="space-y-2 text-xs">
            {asignaturas.map((asig) => {
              const count = matriculasFiltradas.filter((m) => m.asignaturaId === asig.id).length;
              return (
                <div key={asig.id} className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">{asig.nombre}</span>
                    <span className="text-slate-400 text-[10px] ml-2 font-mono">{asig.codigo}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-[11px]">
                    {count} matriculados
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
